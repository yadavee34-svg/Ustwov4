package com.ustwo.app;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.media.MediaMetadataRetriever;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.format.DateUtils;
import android.util.LruCache;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaActionSound;
import android.media.MediaPlayer;
import android.media.ToneGenerator;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Range;
import android.view.GestureDetector;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.SoundEffectConstants;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import androidx.camera.core.ExposureState;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.MeteringPoint;
import androidx.camera.core.ZoomState;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.ListenerRegistration;
import java.util.Calendar;
import java.util.Random;

import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.FallbackStrategy;
import androidx.camera.video.MediaStoreOutputOptions;
import androidx.camera.video.PendingRecording;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.Recorder;
import androidx.camera.video.Recording;
import androidx.camera.video.VideoCapture;
import androidx.camera.video.VideoRecordEvent;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.WindowCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends ComponentActivity {
    // ---- theme colours (set by applyTheme) ----
    private int PINK, LIGHT, BG, TEXT, GRAY, ACCENT, CARD, NAV;
    private boolean dark = false;
    private int theme = 0;
    private boolean soundOn = true;
    private SharedPreferences sp;

    private static class Media { Uri uri; boolean video; long dur; long added; }

    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private final ExecutorService io = Executors.newFixedThreadPool(3);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(24 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };

    private Runnable back = null;
    private LinearLayout shell;
    private FrameLayout content;
    private final TextView[] navIcons = new TextView[5];
    private final TextView[] navLabels = new TextView[5];
    private int tab = 0, homeTab = 0;
    private String myCode = "", partnerUid = "";

    // camera state
    private FrameLayout camRoot, previewFrame;
    private PreviewView previewView;
    private View shutterInner, gridOverlay, focusBox, sunLine, flashOverlay;
    private TextView countdownText, recTimer, modePhoto, modeVideo, flashBtn, timerBtn, zoomHalf, zoomOne, zoomTwo, sunMarker;
    private ImageView galleryThumb;
    private ImageView[] chipImgs;
    private View[] chipFrames;
    private TextView[] chipLabels;
    private LinearLayout topBar, bottomPanel, camCol;
    private HorizontalScrollView filterStrip;
    private VideoCapture<Recorder> videoCapture;
    private ImageCapture imageCapture;
    private Camera camera;
    private Recording recording;
    private CameraSelector selector = CameraSelector.DEFAULT_FRONT_CAMERA;
    private boolean cameraScreen = false, recordingNow = false, effectsOn = true, flashOn = false, photoMode = false, gridOn = true, stripOn = true, counting = false;
    private int filterIndex = 0, intensity = 70, timerSec = 0, exposureBase = 0;
    private float curZoom = 1f;
    private Uri lastUri;
    private MediaActionSound mas;
    private final Random rnd = new Random();
    private Runnable hideFocus, thumbTick, heartTick;

    // chat state
    private ListenerRegistration chatReg;
    private final Map<String, View> bubbleMap = new HashMap<>();
    private LinearLayout chatList, chatNormalRow, chatRecRow;
    private ScrollView chatScroll;
    private boolean chatFirst = true, chatRecording = false;
    private EditText chatInput;
    private TextView actionBtn, chatRecLabel;
    private MediaPlayer vp;
    private TextView vpBtn;
    private MediaRecorder chatRec;
    private File chatRecFile;
    private long chatRecStart;
    private int articleSeed = 0;

    // voice memos
    private File voiceFile;
    private Uri selectedAudioUri;
    private MediaRecorder mediaRecorder;
    private boolean voiceRecording = false;

    private final String[] filterNames = {"Natural", "Pink Glow", "Sweet", "Film", "Dreamy", "B&W", "Vintage", "Sunset", "Cool", "Noir", "Fade", "Warm"};
    // saturation, contrast, brightness add, red mul, green mul, blue mul
    private final float[][] FILTERS = {
            {1f, 1f, 0f, 1f, 1f, 1f}, {1.1f, 1f, 12f, 1.10f, 0.98f, 1.04f}, {1.15f, 0.95f, 15f, 1.08f, 1f, 1.06f},
            {0.85f, 1.15f, -5f, 1.05f, 1f, 0.92f}, {1f, 0.9f, 22f, 1f, 0.98f, 1.10f}, {0f, 1.1f, 0f, 1f, 1f, 1f},
            {0.7f, 0.95f, 8f, 1.12f, 1f, 0.82f}, {1.2f, 1.05f, 8f, 1.18f, 1f, 0.80f}, {0.95f, 1.05f, 0f, 0.88f, 1f, 1.15f},
            {0f, 1.4f, -12f, 1f, 1f, 1f}, {0.75f, 0.8f, 28f, 1f, 1f, 1f}, {1.05f, 1f, 5f, 1.12f, 1.02f, 0.9f}};
    private final String[] heartSets = {"💗,🩷,💖", "💗,🩷,💖", "🩷,💗,✨", "", "✨,💫,⭐", "", "", "☀️,✨,🌅", "❄️,✨,💎", "", "", "✨,🌼,☀️"};

    private final ActivityResultLauncher<String[]> camPerm = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                if (Boolean.TRUE.equals(result.get(Manifest.permission.CAMERA))) showCamera();
                else toast("Camera permission is needed to use the camera.");
            });
    private final ActivityResultLauncher<String> micPerm = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) toast("Microphone allowed. Tap record again.");
                else toast("Microphone permission is needed for voice memos.");
            });
    private final ActivityResultLauncher<String> audioPicker = registerForActivityResult(
            new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) { selectedAudioUri = uri; toast("Audio selected for Bambi Space."); }
            });

    // =====================================================================
    //  Lifecycle
    // =====================================================================
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        sp = getSharedPreferences("ustwo", MODE_PRIVATE);
        soundOn = sp.getBoolean("sound", true);
        applyTheme(sp.getInt("theme", 0));
        mas = new MediaActionSound();
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() { if (back != null) back.run(); else finish(); }
        });
        buildShell();
        if (auth.getCurrentUser() != null) { ensureProfile(); enterApp(); } else showWelcome();
    }

    @Override
    protected void onDestroy() {
        stopChat();
        if (recording != null) recording.stop();
        if (mediaRecorder != null) { try { mediaRecorder.release(); } catch (Exception ignored) { } }
        io.shutdown();
        super.onDestroy();
    }

    // =====================================================================
    //  Small helpers
    // =====================================================================
    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + .5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private GradientDrawable shape(int color, float radiusDp) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radiusDp)); return d; }
    private GradientDrawable oval(int color) { GradientDrawable d = new GradientDrawable(); d.setShape(GradientDrawable.OVAL); d.setColor(color); return d; }
    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }
    private LinearLayout col() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout.LayoutParams lp(int w, int h, int top) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h); p.topMargin = dp(top); return p; }
    private void clipRound(View v, final float r) {
        v.setClipToOutline(true);
        v.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline o) { o.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(r)); }
        });
    }
    private EditText field(String hint, int type) {
        EditText e = new EditText(this); e.setHint(hint); e.setInputType(type); e.setTextColor(TEXT); e.setHintTextColor(GRAY); e.setTextSize(15);
        GradientDrawable g = shape(CARD, 16); g.setStroke(dp(1), LIGHT); e.setBackground(g);
        e.setPadding(dp(16), dp(14), dp(16), dp(14));
        return e;
    }
    private Button pill(String s, int fill, int textColor, int stroke, Runnable r) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextSize(16); b.setTextColor(textColor); b.setStateListAnimator(null);
        GradientDrawable d = shape(fill, 28); if (stroke != 0) d.setStroke(dp(2), stroke);
        b.setBackground(d); b.setOnClickListener(v -> { tick(v); r.run(); }); press(b);
        return b;
    }
    private TextView avatar(String letter, int sizeDp) {
        TextView t = text(letter, 15, Color.WHITE, true); t.setGravity(Gravity.CENTER); t.setBackground(oval(PINK));
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return t;
    }
    private String fmt(long ms) { long s = Math.max(0, ms / 1000); return String.format(Locale.US, "%02d:%02d", s / 60, s % 60); }
    private long num(DocumentSnapshot d, String f) { Long l = d.getLong(f); return l == null ? 0 : l; }
    private void lightBars(boolean light) {
        boolean l = light && !dark;
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(l);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(l);
    }
    private void applyInsets(View v, final boolean top, final boolean bottom) {
        v.setOnApplyWindowInsetsListener((view, ins) -> {
            view.setPadding(0, top ? ins.getSystemWindowInsetTop() : 0, 0, bottom ? ins.getSystemWindowInsetBottom() : 0);
            return ins;
        });
        v.requestApplyInsets();
    }
    private LinearLayout page(String heading) {
        LinearLayout p = col(); p.setPadding(dp(20), dp(16), dp(20), dp(24)); p.setBackgroundColor(BG);
        p.addView(text(heading, 24, TEXT, true));
        return p;
    }
    private ScrollView scroll(View inner) { ScrollView s = new ScrollView(this); s.setBackgroundColor(BG); s.addView(inner); return s; }
    private void loadImage(final String url, final ImageView iv) {
        Bitmap hit = cache.get(url);
        if (hit != null) { iv.setImageBitmap(hit); return; }
        io.execute(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(8000); c.setReadTimeout(8000);
                InputStream in = c.getInputStream();
                final Bitmap bmp = BitmapFactory.decodeStream(in);
                in.close();
                if (bmp != null) { cache.put(url, bmp); runOnUiThread(() -> iv.setImageBitmap(bmp)); }
            } catch (Exception ignored) { }
        });
    }
    private void loadLocalThumb(final Uri uri, final ImageView iv, final int px) {
        io.execute(() -> {
            try {
                final Bitmap bmp = getContentResolver().loadThumbnail(uri, new Size(px, px), null);
                runOnUiThread(() -> iv.setImageBitmap(bmp));
            } catch (Exception ignored) { }
        });
    }

    // =====================================================================
    //  Shell with bottom navigation
    // =====================================================================
    private void buildShell() {
        shell = col(); shell.setBackgroundColor(BG);
        content = new FrameLayout(this);
        shell.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(NAV); nav.setPadding(dp(6), dp(6), dp(6), dp(6)); nav.setElevation(dp(10));
        String[] icons = {"⌂", "✉", "◉", "▦", "☺"};
        String[] labels = {"Home", "Chat", "Camera", "Library", "Profile"};
        for (int i = 0; i < 5; i++) {
            final int n = i;
            LinearLayout item = col(); item.setGravity(Gravity.CENTER);
            TextView ic = text(icons[i], 22, GRAY, true); ic.setGravity(Gravity.CENTER);
            if (i == 2) { ic.setTextColor(Color.WHITE); ic.setBackground(oval(PINK)); ic.setElevation(dp(4)); item.addView(ic, new LinearLayout.LayoutParams(dp(46), dp(46))); }
            else item.addView(ic, new LinearLayout.LayoutParams(-2, dp(34)));
            TextView lb = text(labels[i], 11, GRAY, false); lb.setGravity(Gravity.CENTER);
            item.addView(lb);
            press(item);
            item.setOnClickListener(v -> { tick(v); if (n == 2) requestCamera(); else go(n); });
            nav.addView(item, new LinearLayout.LayoutParams(0, -2, 1f));
            navIcons[i] = ic; navLabels[i] = lb;
        }
        shell.addView(nav, new LinearLayout.LayoutParams(-1, -2));
    }
    private void updateNav() {
        for (int i = 0; i < 5; i++) {
            int c = (i == tab || i == 2) ? PINK : GRAY;
            navLabels[i].setTextColor(c);
            if (i != 2) navIcons[i].setTextColor(c);
        }
    }
    private void enterApp() {
        cameraScreen = false; lightBars(true);
        setContentView(shell); applyInsets(shell, true, true);
        go(tab);
    }
    private void go(int i) {
        back = null; tab = i; stopChat(); updateNav();
        content.removeAllViews();
        View v = i == 0 ? buildHome() : i == 1 ? buildChat() : i == 3 ? buildLibrary() : buildProfile();
        content.addView(v, new FrameLayout.LayoutParams(-1, -1));
        fadeIn(v, 0);
    }
    private void push(View v) {
        back = () -> go(tab); stopChat();
        content.removeAllViews();
        content.addView(v, new FrameLayout.LayoutParams(-1, -1));
        fadeIn(v, 0);
    }

    // =====================================================================
    //  Welcome and sign in
    // =====================================================================
    private void showWelcome() {
        back = null; cameraScreen = false; lightBars(true);
        FrameLayout f = new FrameLayout(this);
        f.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, welcomeColors()));
        LinearLayout c = col(); c.setGravity(Gravity.CENTER_HORIZONTAL); c.setPadding(dp(32), dp(56), dp(32), dp(32));
        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.ic_heart); logo.setColorFilter(Color.WHITE);
        c.addView(logo, new LinearLayout.LayoutParams(dp(88), dp(88)));
        TextView title = text("UsTwo", 54, Color.WHITE, true); title.setTypeface(Typeface.create("cursive", Typeface.BOLD));
        c.addView(title, lp(-2, -2, 8));
        c.addView(text("Our Vlogs. Our Story.", 15, Color.WHITE, false), lp(-2, -2, 2));
        View sp = new View(this); c.addView(sp, new LinearLayout.LayoutParams(1, 0, 1f));
        c.addView(pill("Get Started", PINK, Color.WHITE, 0, () -> showAuth(true)), lp(-1, dp(54), 0));
        c.addView(pill("Login", Color.TRANSPARENT, Color.WHITE, Color.WHITE, () -> showAuth(false)), lp(-1, dp(54), 12));
        TextView foot = text("Just the two of us ♡", 13, Color.WHITE, false); foot.setGravity(Gravity.CENTER);
        c.addView(foot, lp(-1, -2, 22));
        f.addView(c, new FrameLayout.LayoutParams(-1, -1));
        setContentView(f); applyInsets(f, true, true);
        getWindow().getDecorView().post(() -> lightBars(true));
    }

    private void showAuth(final boolean signup) {
        back = this::showWelcome; lightBars(true);
        LinearLayout p = col(); p.setPadding(dp(24), dp(16), dp(24), dp(24)); p.setBackgroundColor(BG);
        TextView bk = text("←", 28, TEXT, false); bk.setOnClickListener(v -> showWelcome()); p.addView(bk);
        TextView h = text(signup ? "Create your account" : "Welcome back", 26, TEXT, true); p.addView(h, lp(-2, -2, 18));
        p.addView(text(signup ? "Just the two of us. Private by default." : "Log in to see your vlogs.", 14, GRAY, false), lp(-2, -2, 4));
        final EditText email = field("Email address", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        final EditText pw = field("Password (6+ characters)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        p.addView(email, lp(-1, -2, 24)); p.addView(pw, lp(-1, -2, 12));
        final String label = signup ? "Create account" : "Log in";
        final Button[] bb = new Button[1];
        bb[0] = pill(label, PINK, Color.WHITE, 0, () -> {
            String e = email.getText().toString().trim(), pwd = pw.getText().toString();
            if (e.isEmpty() || pwd.length() < 6) { toast("Enter your email and a password with at least 6 characters."); return; }
            bb[0].setEnabled(false); bb[0].setText("Please wait…");
            if (signup) auth.createUserWithEmailAndPassword(e, pwd).addOnSuccessListener(r -> authOk()).addOnFailureListener(err -> authFail(err, bb[0], label));
            else auth.signInWithEmailAndPassword(e, pwd).addOnSuccessListener(r -> authOk()).addOnFailureListener(err -> authFail(err, bb[0], label));
        });
        p.addView(bb[0], lp(-1, dp(54), 20));
        TextView sw = text(signup ? "Already have an account? Log in" : "New here? Create an account", 14, PINK, true);
        sw.setGravity(Gravity.CENTER); sw.setPadding(0, dp(16), 0, dp(16)); sw.setOnClickListener(v -> showAuth(!signup));
        p.addView(sw, lp(-1, -2, 8));
        setContentView(scroll(p)); applyInsets(findViewById(android.R.id.content), true, true);
    }
    private void authOk() { ensureProfile(); tab = 0; homeTab = 0; enterApp(); }
    private void authFail(Exception err, Button b, String label) {
        b.setEnabled(true); b.setText(label);
        new AlertDialog.Builder(this).setTitle("Couldn't continue").setMessage(friendly(err)).setPositiveButton("OK", null).show();
    }
    private String friendly(Exception e) {
        String raw = e.getMessage() == null ? e.toString() : e.getMessage();
        String code = (e instanceof FirebaseAuthException) ? ((FirebaseAuthException) e).getErrorCode() : "";
        String msg = "Something went wrong.";
        if (code.equals("ERROR_EMAIL_ALREADY_IN_USE")) msg = "That email already has an account. Use Log in instead.";
        else if (code.equals("ERROR_WEAK_PASSWORD")) msg = "Choose a stronger password (6+ characters).";
        else if (code.equals("ERROR_INVALID_EMAIL")) msg = "That email address doesn't look right.";
        else if (code.equals("ERROR_INVALID_CREDENTIAL") || code.equals("ERROR_WRONG_PASSWORD") || code.equals("ERROR_USER_NOT_FOUND")) msg = "Wrong email or password.";
        if (e instanceof FirebaseNetworkException) msg = "No internet connection. Check your data or Wi-Fi.";
        if (raw.contains("CONFIGURATION_NOT_FOUND") || code.equals("ERROR_OPERATION_NOT_ALLOWED"))
            msg = "Email sign-in isn't switched on in Firebase yet. In the Firebase console go to Build > Authentication > Sign-in method > Email/Password and enable it.";
        if (raw.contains("permission") || raw.contains("PERMISSION_DENIED"))
            msg = "Firebase denied this. Check that your Firestore/Storage rules are published.";
        return msg + "\n\n(" + raw + ")";
    }
    private void ensureProfile() {
        FirebaseUser u = auth.getCurrentUser(); if (u == null) return;
        myCode = u.getUid().substring(0, 6).toUpperCase(Locale.US);
        Map<String, Object> m = new HashMap<>();
        m.put("email", u.getEmail()); m.put("code", myCode); m.put("uid", u.getUid());
        db.collection("profiles").document(u.getUid()).set(m, SetOptions.merge());
        db.collection("profiles").document(u.getUid()).get().addOnSuccessListener(d -> {
            String pu = d.getString("partnerUid"); partnerUid = pu == null ? "" : pu;
            Long ts = d.getLong("togetherSince"); if (ts != null && sp.getLong("since", 0) == 0) sp.edit().putLong("since", ts).apply();
        });
    }

    // =====================================================================
    //  Home: For You / Our Memories
    // =====================================================================


    private void loadFeed(final LinearLayout list) {
        final FirebaseUser u = auth.getCurrentUser();
        if (u == null) { showWelcome(); return; }
        final TextView loading = text("Loading your vlogs…", 14, GRAY, false); loading.setGravity(Gravity.CENTER); loading.setPadding(0, dp(40), 0, 0);
        list.addView(loading);
        final List<DocumentSnapshot> all = new ArrayList<>();
        final int[] pending = {2};
        final String[] err = {null};
        final Runnable done = () -> {
            if (--pending[0] > 0) return;
            list.removeAllViews();
            Set<String> seen = new HashSet<>(); List<DocumentSnapshot> uniq = new ArrayList<>();
            for (DocumentSnapshot d : all) if (seen.add(d.getId())) uniq.add(d);
            Collections.sort(uniq, (a, b2) -> Long.compare(num(b2, "createdAt"), num(a, "createdAt")));
            if (err[0] != null && uniq.isEmpty()) {
                TextView t = text("Couldn't load vlogs.\n" + err[0] + "\n\nCheck that Firestore is created and the rules are published.", 13, GRAY, false);
                t.setPadding(0, dp(30), 0, 0); list.addView(t); return;
            }
            if (uniq.isEmpty()) {
                TextView t = text("No vlogs yet 💗\nTap the camera, record something, then upload it to share with your partner.", 14, GRAY, false);
                t.setGravity(Gravity.CENTER); t.setPadding(dp(16), dp(40), dp(16), 0); list.addView(t); return;
            }
            for (DocumentSnapshot d : uniq) list.addView(feedCard(d, u.getUid()), lp(-1, -2, 14));
        };
        db.collection("vlogs").whereEqualTo("ownerUid", u.getUid()).get()
                .addOnSuccessListener(qs -> { all.addAll(qs.getDocuments()); done.run(); })
                .addOnFailureListener(e -> { err[0] = e.getMessage(); done.run(); });
        db.collection("vlogs").whereEqualTo("partnerUid", u.getUid()).get()
                .addOnSuccessListener(qs -> { all.addAll(qs.getDocuments()); done.run(); })
                .addOnFailureListener(e -> { err[0] = e.getMessage(); done.run(); });
    }

    private View feedCard(final DocumentSnapshot d, final String me) {
        LinearLayout card = col(); card.setBackground(shape(CARD, 18)); card.setPadding(dp(8), dp(8), dp(8), dp(12)); card.setElevation(dp(2));
        FrameLayout media = new FrameLayout(this); media.setBackground(shape(LIGHT, 14)); clipRound(media, 14);
        ImageView iv = new ImageView(this); iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        media.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        String thumb = d.getString("thumbUrl"); if (thumb != null && !thumb.isEmpty()) loadImage(thumb, iv);
        TextView play = text("▶", 20, Color.WHITE, false); play.setGravity(Gravity.CENTER); play.setBackground(oval(Color.argb(110, 0, 0, 0)));
        media.addView(play, new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER));
        TextView chip = text(fmt(num(d, "durationMs")), 11, Color.WHITE, true); chip.setPadding(dp(8), dp(3), dp(8), dp(3)); chip.setBackground(shape(Color.argb(140, 0, 0, 0), 10));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START); cp.setMargins(dp(10), 0, 0, dp(10));
        media.addView(chip, cp);
        final String url = d.getString("videoUrl");
        media.setOnClickListener(v -> { if (url != null) showPlayer(Uri.parse(url), false, this::enterApp); });
        card.addView(media, new LinearLayout.LayoutParams(-1, dp(190)));
        LinearLayout r = row(); r.setPadding(dp(6), dp(10), dp(6), 0);
        String cap = d.getString("caption"); if (cap == null || cap.isEmpty()) cap = "Untitled vlog";
        LinearLayout left = col();
        left.addView(text(cap, 15, TEXT, true));
        String who = me.equals(d.getString("ownerUid")) ? "You" : "Partner";
        String tag = d.getString("tag");
        left.addView(text(who + " • " + DateUtils.getRelativeTimeSpanString(num(d, "createdAt"), System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS) + (tag == null || tag.isEmpty() ? "" : " • " + tag), 12, GRAY, false));
        r.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        List<?> lb = (List<?>) d.get("likedBy");
        final boolean liked = lb != null && lb.contains(me);
        TextView like = text("♥ " + (lb == null ? 0 : lb.size()), 14, liked ? PINK : GRAY, true); like.setPadding(dp(10), dp(6), dp(6), dp(6));
        like.setOnClickListener(v -> d.getReference().update("likedBy", liked ? FieldValue.arrayRemove(me) : FieldValue.arrayUnion(me))
                .addOnSuccessListener(x -> go(0)).addOnFailureListener(e -> toast("Couldn't update: " + e.getMessage())));
        r.addView(like);
        card.addView(r);
        return card;
    }

    private void buildMemories(final LinearLayout list) {
        final FirebaseUser u = auth.getCurrentUser(); if (u == null) return;
        list.addView(text("Little notes for the two of you. Only you can see these for now.", 13, GRAY, false));
        final EditText title = field("Memory title", InputType.TYPE_CLASS_TEXT);
        final EditText body = field("Write a memory or love note…", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        body.setMinLines(3);
        list.addView(title, lp(-1, -2, 12)); list.addView(body, lp(-1, -2, 8));
        list.addView(pill("Save memory", PINK, Color.WHITE, 0, () -> {
            String tt = title.getText().toString().trim(), bd = body.getText().toString().trim();
            if (tt.isEmpty() && bd.isEmpty()) { toast("Write something first."); return; }
            Map<String, Object> m = new HashMap<>(); m.put("title", tt); m.put("body", bd); m.put("createdAt", System.currentTimeMillis()); m.put("uid", u.getUid());
            db.collection("users").document(u.getUid()).collection("memories").add(m)
                    .addOnSuccessListener(r -> { toast("Memory saved 💗"); go(0); })
                    .addOnFailureListener(e -> toast("Could not save: " + e.getMessage()));
        }), lp(-1, dp(50), 10));
        db.collection("users").document(u.getUid()).collection("memories").get().addOnSuccessListener(qs -> {
            List<DocumentSnapshot> docs = new ArrayList<>(qs.getDocuments());
            Collections.sort(docs, (a, b2) -> Long.compare(num(b2, "createdAt"), num(a, "createdAt")));
            for (DocumentSnapshot d : docs) {
                LinearLayout c = col(); c.setBackground(shape(CARD, 16)); c.setPadding(dp(14), dp(12), dp(14), dp(12));
                String t = d.getString("title"), b3 = d.getString("body");
                if (t != null && !t.isEmpty()) c.addView(text(t, 15, TEXT, true));
                if (b3 != null && !b3.isEmpty()) c.addView(text(b3, 14, TEXT, false), lp(-2, -2, 4));
                c.addView(text(DateUtils.getRelativeTimeSpanString(num(d, "createdAt"), System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString(), 11, GRAY, false), lp(-2, -2, 6));
                list.addView(c, lp(-1, -2, 10));
            }
        });
    }

    // =====================================================================
    //  Library (media saved on this phone)
    // =====================================================================
    private List<Media> queryMedia() {
        List<Media> out = new ArrayList<>();
        try (Cursor c = getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Video.Media._ID, MediaStore.Video.Media.DURATION, MediaStore.Video.Media.DATE_ADDED},
                MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?", new String[]{"Movies/UsTwo%"}, MediaStore.MediaColumns.DATE_ADDED + " DESC")) {
            if (c != null) while (c.moveToNext()) {
                Media m = new Media(); m.video = true; m.dur = c.getLong(1); m.added = c.getLong(2);
                m.uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, c.getLong(0)); out.add(m);
            }
        } catch (Exception ignored) { }
        try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_ADDED},
                MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?", new String[]{"Pictures/UsTwo%"}, MediaStore.MediaColumns.DATE_ADDED + " DESC")) {
            if (c != null) while (c.moveToNext()) {
                Media m = new Media(); m.video = false; m.added = c.getLong(1);
                m.uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(0)); out.add(m);
            }
        } catch (Exception ignored) { }
        Collections.sort(out, (a, b2) -> Long.compare(b2.added, a.added));
        return out;
    }

    private View buildLibrary() {
        LinearLayout p = col(); p.setBackgroundColor(BG); p.setPadding(dp(16), dp(14), dp(16), dp(8));
        p.addView(text("Library", 26, TEXT, true));
        p.addView(text("Photos and vlogs saved on this phone", 13, GRAY, false), lp(-2, -2, 2));
        LinearLayout grid = col();
        ScrollView sv = new ScrollView(this); sv.addView(grid);
        p.addView(sv, lp(-1, 0, 12));
        ((LinearLayout.LayoutParams) sv.getLayoutParams()).weight = 1f;
        List<Media> items = queryMedia();
        if (items.isEmpty()) {
            TextView t = text("Nothing here yet.\nTap the camera to record your first moment 💗", 14, GRAY, false);
            t.setGravity(Gravity.CENTER); t.setPadding(0, dp(50), 0, 0); grid.addView(t);
        }
        for (int i = 0; i < items.size(); i += 2) {
            LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL);
            for (int j = 0; j < 2; j++) {
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(180), 1f);
                cp.setMargins(dp(j == 0 ? 0 : 5), dp(5), dp(j == 0 ? 5 : 0), dp(5));
                if (i + j < items.size()) r.addView(mediaCell(items.get(i + j)), cp);
                else r.addView(new View(this), cp);
            }
            grid.addView(r);
        }
        return p;
    }

    private View mediaCell(final Media m) {
        FrameLayout f = new FrameLayout(this); f.setBackground(shape(LIGHT, 14)); clipRound(f, 14);
        ImageView iv = new ImageView(this); iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        loadLocalThumb(m.uri, iv, 400);
        if (m.video) {
            TextView play = text("▶", 16, Color.WHITE, false); play.setGravity(Gravity.CENTER); play.setBackground(oval(Color.argb(110, 0, 0, 0)));
            f.addView(play, new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER));
            TextView chip = text(fmt(m.dur), 11, Color.WHITE, true); chip.setPadding(dp(8), dp(3), dp(8), dp(3)); chip.setBackground(shape(Color.argb(140, 0, 0, 0), 10));
            FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START); cp.setMargins(dp(8), 0, 0, dp(8));
            f.addView(chip, cp);
        }
        f.setOnClickListener(v -> {
            if (m.video) showPlayer(m.uri, true, this::enterApp);
            else { Intent i = new Intent(Intent.ACTION_VIEW); i.setDataAndType(m.uri, "image/*"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); try { startActivity(i); } catch (Exception e) { toast("No photo viewer found."); } }
        });
        return f;
    }

    // =====================================================================
    //  Player / review screen
    // =====================================================================
    private void showPlayer(final Uri uri, boolean canUpload, final Runnable onBack) {
        cameraScreen = false; back = onBack; lightBars(false);
        LinearLayout p = col(); p.setBackgroundColor(Color.BLACK);
        LinearLayout bar = row(); bar.setPadding(dp(14), dp(8), dp(14), dp(8));
        TextView x = text("←", 28, Color.WHITE, false); x.setOnClickListener(v -> onBack.run()); bar.addView(x);
        p.addView(bar);
        FrameLayout vf = new FrameLayout(this);
        final VideoView vv = new VideoView(this);
        vf.addView(vv, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        final TextView playBtn = text("▶", 30, Color.WHITE, false); playBtn.setGravity(Gravity.CENTER); playBtn.setBackground(oval(Color.argb(120, 0, 0, 0)));
        vf.addView(playBtn, new FrameLayout.LayoutParams(dp(72), dp(72), Gravity.CENTER));
        final TextView time = text("00:00 / 00:00", 12, Color.WHITE, true);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START); tp.setMargins(dp(16), 0, 0, dp(14));
        vf.addView(time, tp);
        p.addView(vf, new LinearLayout.LayoutParams(-1, 0, 1f));
        if (canUpload) {
            p.addView(pill("Save & Upload", PINK, Color.WHITE, 0, () -> showUpload(uri, onBack)), lp(-1, dp(54), 10));
            ((LinearLayout.LayoutParams) p.getChildAt(p.getChildCount() - 1).getLayoutParams()).setMargins(dp(20), dp(10), dp(20), dp(14));
        }
        setContentView(p); applyInsets(p, true, true);
        final Runnable[] tick = new Runnable[1];
        tick[0] = () -> {
            if (!vv.isAttachedToWindow()) return;
            if (vv.getDuration() > 0) time.setText(fmt(vv.getCurrentPosition()) + " / " + fmt(vv.getDuration()));
            main.postDelayed(tick[0], 400);
        };
        vv.setOnPreparedListener(mp -> { playBtn.setVisibility(View.GONE); vv.start(); main.post(tick[0]); });
        vv.setOnCompletionListener(mp -> playBtn.setVisibility(View.VISIBLE));
        vv.setOnErrorListener((mp, what, extra) -> { toast("Couldn't play this video."); return true; });
        vf.setOnClickListener(v -> {
            if (vv.isPlaying()) { vv.pause(); playBtn.setVisibility(View.VISIBLE); }
            else { vv.start(); playBtn.setVisibility(View.GONE); }
        });
        vv.setVideoURI(uri);
    }

    // =====================================================================
    //  Upload to partner
    // =====================================================================
    private void showUpload(final Uri uri, final Runnable onBack) {
        back = () -> showPlayer(uri, true, onBack); lightBars(true);
        LinearLayout p = col(); p.setPadding(dp(20), dp(12), dp(20), dp(24)); p.setBackgroundColor(BG);
        LinearLayout bar = row();
        TextView bk = text("←", 28, TEXT, false); bk.setOnClickListener(v -> back.run()); bar.addView(bk);
        TextView ttl = text("Upload to Partner", 18, TEXT, true); ttl.setGravity(Gravity.CENTER); bar.addView(ttl, new LinearLayout.LayoutParams(0, -2, 1f));
        View sp = new View(this); bar.addView(sp, new LinearLayout.LayoutParams(dp(28), 1));
        p.addView(bar);
        FrameLayout media = new FrameLayout(this); media.setBackground(shape(LIGHT, 16)); clipRound(media, 16);
        ImageView iv = new ImageView(this); iv.setScaleType(ImageView.ScaleType.CENTER_CROP); media.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        loadLocalThumb(uri, iv, 800);
        final TextView chip = text("", 11, Color.WHITE, true); chip.setPadding(dp(8), dp(3), dp(8), dp(3)); chip.setBackground(shape(Color.argb(140, 0, 0, 0), 10));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END); cp.setMargins(0, 0, dp(10), dp(10));
        media.addView(chip, cp);
        io.execute(() -> {
            try { MediaMetadataRetriever r = new MediaMetadataRetriever(); r.setDataSource(this, uri); String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION); r.release();
                if (d != null) { final long ms = Long.parseLong(d); runOnUiThread(() -> chip.setText(fmt(ms))); } } catch (Exception ignored) { }
        });
        p.addView(media, lp(-1, dp(200), 16));
        final EditText caption = field("Add a caption…", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        caption.setMinLines(3); caption.setGravity(Gravity.TOP);
        p.addView(caption, lp(-1, -2, 14));
        final String[] tags = {"Vlog", "Date", "Daily"};
        final String[] sel = {"Vlog"};
        final TextView[] chips = new TextView[3];
        LinearLayout cr = row();
        for (int i = 0; i < 3; i++) {
            final int n = i;
            chips[i] = text(tags[i], 13, GRAY, false); chips[i].setPadding(dp(18), dp(8), dp(18), dp(8)); chips[i].setBackground(shape(ACCENT, 20));
            chips[i].setOnClickListener(v -> {
                sel[0] = tags[n];
                for (int k = 0; k < 3; k++) { boolean on = k == n; chips[k].setTextColor(on ? Color.WHITE : GRAY); chips[k].setBackground(shape(on ? PINK : ACCENT, 20)); }
            });
            LinearLayout.LayoutParams chp = new LinearLayout.LayoutParams(-2, -2); chp.rightMargin = dp(10);
            cr.addView(chips[i], chp);
        }
        chips[0].setTextColor(Color.WHITE); chips[0].setBackground(shape(PINK, 20));
        p.addView(cr, lp(-2, -2, 12));
        p.addView(text("🔒  Privacy", 15, TEXT, true), lp(-2, -2, 18));
        String priv = partnerUid.isEmpty() ? "Only you can see this until you link your partner (Profile > Link partner)." : "Only you and your partner can see this.";
        p.addView(text(priv, 12, GRAY, false), lp(-2, -2, 4));
        final Button[] bb = new Button[1];
        bb[0] = pill("Upload", PINK, Color.WHITE, 0, () -> uploadVlog(uri, caption.getText().toString().trim(), sel[0], bb[0]));
        p.addView(bb[0], lp(-1, dp(54), 24));
        setContentView(scroll(p)); applyInsets(findViewById(android.R.id.content), true, true);
    }

    private void uploadVlog(final Uri uri, final String caption, final String tag, final Button btn) {
        final FirebaseUser u = auth.getCurrentUser();
        if (u == null) { toast("Please log in first."); showAuth(false); return; }
        btn.setEnabled(false); btn.setText("Preparing…");
        io.execute(() -> {
            byte[] thumbBytes = null; long dur = 0;
            try { Bitmap bm = getContentResolver().loadThumbnail(uri, new Size(640, 640), null); ByteArrayOutputStream bo = new ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.JPEG, 85, bo); thumbBytes = bo.toByteArray(); } catch (Exception ignored) { }
            try { MediaMetadataRetriever r = new MediaMetadataRetriever(); r.setDataSource(this, uri); String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION); if (d != null) dur = Long.parseLong(d); r.release(); } catch (Exception ignored) { }
            final byte[] tb = thumbBytes; final long dd = dur;
            runOnUiThread(() -> startUpload(u, uri, tb, dd, caption, tag, btn));
        });
    }
    private void startUpload(final FirebaseUser u, Uri uri, final byte[] tb, final long dur, final String caption, final String tag, final Button btn) {
        String id = String.valueOf(System.currentTimeMillis());
        final StorageReference vref = storage.getReference().child("users/" + u.getUid() + "/vlogs/" + id + ".mp4");
        final StorageReference tref = storage.getReference().child("users/" + u.getUid() + "/vlogs/" + id + ".jpg");
        btn.setText("Uploading 0%");
        vref.putFile(uri)
                .addOnProgressListener(s -> { long t = Math.max(1, s.getTotalByteCount()); btn.setText("Uploading " + (100 * s.getBytesTransferred() / t) + "%"); })
                .addOnSuccessListener(s -> vref.getDownloadUrl()
                        .addOnSuccessListener(vurl -> uploadThumb(u, vurl.toString(), tref, tb, dur, caption, tag, btn))
                        .addOnFailureListener(e -> uploadFail(e, btn)))
                .addOnFailureListener(e -> uploadFail(e, btn));
    }
    private void uploadThumb(final FirebaseUser u, final String vurl, final StorageReference tref, byte[] tb, final long dur, final String caption, final String tag, final Button btn) {
        if (tb == null) { saveVlog(u, vurl, "", dur, caption, tag, btn); return; }
        tref.putBytes(tb)
                .addOnSuccessListener(s -> tref.getDownloadUrl()
                        .addOnSuccessListener(turl -> saveVlog(u, vurl, turl.toString(), dur, caption, tag, btn))
                        .addOnFailureListener(e -> saveVlog(u, vurl, "", dur, caption, tag, btn)))
                .addOnFailureListener(e -> saveVlog(u, vurl, "", dur, caption, tag, btn));
    }
    private void saveVlog(FirebaseUser u, String vurl, String turl, long dur, String caption, String tag, final Button btn) {
        Map<String, Object> m = new HashMap<>();
        m.put("ownerUid", u.getUid()); m.put("ownerEmail", u.getEmail()); m.put("partnerUid", partnerUid == null ? "" : partnerUid);
        m.put("videoUrl", vurl); m.put("thumbUrl", turl); m.put("durationMs", dur); m.put("caption", caption); m.put("tag", tag);
        m.put("likedBy", new ArrayList<String>()); m.put("createdAt", System.currentTimeMillis());
        db.collection("vlogs").add(m)
                .addOnSuccessListener(r -> { toast("Uploaded! 💗"); tab = 0; homeTab = 0; enterApp(); })
                .addOnFailureListener(e -> uploadFail(e, btn));
    }
    private void uploadFail(Exception e, Button btn) {
        btn.setEnabled(true); btn.setText("Upload");
        new AlertDialog.Builder(this).setTitle("Upload failed")
                .setMessage("Check that Firebase Storage is enabled and your Firestore/Storage rules are published.\n\n(" + e.getMessage() + ")")
                .setPositiveButton("OK", null).show();
    }

    // =====================================================================
    //  Profile + partner linking
    // =====================================================================

    private void linkPartner(String raw) {
        final FirebaseUser u = auth.getCurrentUser(); if (u == null) return;
        String code = raw.trim().toUpperCase(Locale.US);
        if (code.isEmpty()) { toast("Enter your partner's code."); return; }
        if (code.equals(myCode)) { toast("That's your own code. Enter your partner's."); return; }
        db.collection("profiles").whereEqualTo("code", code).get().addOnSuccessListener(qs -> {
            if (qs.isEmpty()) { toast("No account found with that code."); return; }
            DocumentSnapshot d = qs.getDocuments().get(0);
            final String pu = d.getId(); final String pe = d.getString("email");
            Map<String, Object> m = new HashMap<>(); m.put("partnerUid", pu);
            db.collection("profiles").document(u.getUid()).set(m, SetOptions.merge())
                    .addOnSuccessListener(x -> { partnerUid = pu; toast("Linked with " + pe + " 💗"); go(4); })
                    .addOnFailureListener(e -> toast("Couldn't link: " + e.getMessage()));
        }).addOnFailureListener(e -> toast("Couldn't look up that code: " + e.getMessage()));
    }

    // =====================================================================
    //  Bambi Space (voice memos)
    // =====================================================================
    private void bambiScreen() {
        LinearLayout p = page("🎵 Bambi Space");
        p.addView(text("A little corner for your song covers, voice memos and music moments.", 14, GRAY, false), lp(-2, -2, 4));
        p.addView(pill("● Record / stop voice memo", PINK, Color.WHITE, 0, this::toggleVoiceMemo), lp(-1, dp(50), 16));
        p.addView(pill("▶ Play last memo", ACCENT, PINK, 0, this::playVoiceMemo), lp(-1, dp(50), 10));
        p.addView(pill("↗ Share last memo", ACCENT, PINK, 0, this::shareVoiceMemo), lp(-1, dp(50), 10));
        p.addView(pill("Upload to my private space", ACCENT, PINK, 0, this::uploadVoiceMemo), lp(-1, dp(50), 10));
        p.addView(pill("Choose an audio file", ACCENT, PINK, 0, () -> audioPicker.launch("audio/*")), lp(-1, dp(50), 10));
        p.addView(text("Uploads need you to be signed in. Files go to your private Firebase folder.", 12, GRAY, false), lp(-2, -2, 12));
        push(scroll(p));
    }
    private void toggleVoiceMemo() {
        if (!voiceRecording) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { micPerm.launch(Manifest.permission.RECORD_AUDIO); return; }
            try {
                voiceFile = new File(getExternalFilesDir(null), "bambi_" + System.currentTimeMillis() + ".m4a");
                mediaRecorder = new MediaRecorder();
                mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                mediaRecorder.setOutputFile(voiceFile.getAbsolutePath());
                mediaRecorder.prepare(); mediaRecorder.start();
                voiceRecording = true; toast("Recording voice memo… tap again to stop.");
            } catch (Exception e) { voiceRecording = false; toast("Could not start recording: " + e.getMessage()); }
        } else {
            try { mediaRecorder.stop(); mediaRecorder.release(); mediaRecorder = null; voiceRecording = false; toast("Voice memo saved on this phone."); }
            catch (Exception e) { voiceRecording = false; toast("Recording could not be finalized."); }
        }
    }
    private Uri currentAudio() {
        if (selectedAudioUri != null) return selectedAudioUri;
        if (voiceFile != null && voiceFile.exists()) return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", voiceFile);
        return null;
    }
    private void playVoiceMemo() {
        Uri a = currentAudio(); if (a == null) { toast("Record a voice memo first, or choose an audio file."); return; }
        Intent i = new Intent(Intent.ACTION_VIEW); i.setDataAndType(a, "audio/*"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(i); } catch (Exception e) { toast("No audio player found."); }
    }
    private void shareVoiceMemo() {
        Uri a = currentAudio(); if (a == null) { toast("Record a voice memo or choose an audio file first."); return; }
        Intent i = new Intent(Intent.ACTION_SEND); i.setType("audio/*"); i.putExtra(Intent.EXTRA_STREAM, a); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Share with"));
    }
    private void uploadVoiceMemo() {
        final FirebaseUser u = auth.getCurrentUser();
        if (u == null) { toast("Sign in before uploading."); return; }
        final Uri source; final String fileName;
        if (selectedAudioUri != null) { source = selectedAudioUri; fileName = "cover_" + System.currentTimeMillis() + ".audio"; }
        else if (voiceFile != null && voiceFile.exists()) { source = Uri.fromFile(voiceFile); fileName = voiceFile.getName(); }
        else { toast("Record a voice memo or choose an audio file first."); return; }
        final StorageReference ref = storage.getReference().child("users/" + u.getUid() + "/bambi/" + fileName);
        toast("Uploading…");
        ref.putFile(source).addOnSuccessListener(t -> ref.getDownloadUrl().addOnSuccessListener(url -> {
            Map<String, Object> song = new HashMap<>();
            song.put("name", fileName); song.put("url", url.toString()); song.put("createdAt", System.currentTimeMillis()); song.put("uid", u.getUid());
            db.collection("users").document(u.getUid()).collection("bambiTracks").add(song)
                    .addOnSuccessListener(r -> toast("Audio uploaded to your Bambi Space."))
                    .addOnFailureListener(e -> toast("Uploaded, but saving details failed: " + e.getMessage()));
        })).addOnFailureListener(e -> toast("Upload failed: " + e.getMessage()));
    }

    // =====================================================================
    //  Themes, haptics and motion
    // =====================================================================
    private void applyTheme(int t) {
        theme = t; dark = t == 1;
        if (t == 1) {            // Midnight purple
            PINK = Color.parseColor("#A66BFF"); LIGHT = Color.parseColor("#2B1850"); BG = Color.parseColor("#130A24");
            TEXT = Color.parseColor("#F4ECFF"); GRAY = Color.parseColor("#A79BC4"); ACCENT = Color.parseColor("#2A1B4A");
            CARD = Color.parseColor("#1F1236"); NAV = Color.parseColor("#190E2E");
        } else if (t == 2) {     // Cream and rose
            PINK = Color.parseColor("#E8807F"); LIGHT = Color.parseColor("#F6D9D3"); BG = Color.parseColor("#FFF6EE");
            TEXT = Color.parseColor("#5B3F3F"); GRAY = Color.parseColor("#B49C98"); ACCENT = Color.parseColor("#FBE7E1");
            CARD = Color.parseColor("#FFFFFF"); NAV = Color.parseColor("#FFFBF7");
        } else {                 // Blush pink (original colours)
            PINK = Color.parseColor("#FF8FA3"); LIGHT = Color.parseColor("#FDD6E7"); BG = Color.parseColor("#FFF7F9");
            TEXT = Color.parseColor("#4A4A4A"); GRAY = Color.parseColor("#A7A7A7"); ACCENT = Color.parseColor("#FFE3E7");
            CARD = Color.parseColor("#FFFFFF"); NAV = Color.parseColor("#FFFFFF");
        }
    }
    private int[] welcomeColors() {
        if (theme == 1) return new int[]{Color.parseColor("#3A1D78"), Color.parseColor("#26124F"), Color.parseColor("#170B33"), Color.parseColor("#0C0518")};
        if (theme == 2) return new int[]{Color.parseColor("#FFE9DC"), Color.parseColor("#F9C9BF"), Color.parseColor("#E8A09C"), Color.parseColor("#9A6A6A")};
        return new int[]{Color.parseColor("#FFD9C7"), Color.parseColor("#FF9FB0"), Color.parseColor("#B76A86"), Color.parseColor("#3B2A3F")};
    }
    private int mix(int a, int b, float t) {
        return Color.rgb((int) (Color.red(a) * (1 - t) + Color.red(b) * t), (int) (Color.green(a) * (1 - t) + Color.green(b) * t), (int) (Color.blue(a) * (1 - t) + Color.blue(b) * t));
    }
    private void tick(View v) {
        if (!soundOn || v == null) return;
        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
        v.playSoundEffect(SoundEffectConstants.CLICK);
    }
    private void press(View v) {
        v.setOnTouchListener((view, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) view.animate().scaleX(.95f).scaleY(.95f).setDuration(90).setInterpolator(new DecelerateInterpolator()).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) view.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(new OvershootInterpolator(2.4f)).start();
            return false;
        });
    }
    private void tapable(View v, final Runnable r) { press(v); v.setOnClickListener(x -> { tick(x); r.run(); }); }
    private void fadeIn(View v, int delayMs) {
        v.setAlpha(0f); v.setTranslationY(dp(16));
        v.animate().alpha(1f).translationY(0f).setStartDelay(delayMs).setDuration(340).setInterpolator(new DecelerateInterpolator(1.7f)).start();
    }
    private String fmtDate(long ms) { return new SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(new Date(ms)); }

    // =====================================================================
    //  Articles and little daily messages (original content)
    // =====================================================================
    private static final String[] QUOTES = {
            "Small moments, done together, become the story you tell forever.",
            "Ask one curious question today and listen all the way to the end.",
            "Love is a verb. Do one kind thing for them before lunch.",
            "You don't have to agree on everything, only on how you treat each other.",
            "A hug that lasts a full twenty seconds changes the whole day.",
            "Say the thank-you you've been thinking but not saying.",
            "Be the safe place your person wants to come home to.",
            "Plan something small to look forward to this week.",
            "Put the phone down for ten minutes and just look at each other.",
            "Choose them again today, in a small and ordinary way.",
            "Tell them one thing that made you smile because of them.",
            "Soft words, honest hearts, patient days."};

    private static final String[][] ARTICLES = {
            {"💬", "The 10-minute daily check-in", "Communication", "3",
                    "Most couples talk all day and still miss each other. A short, protected check-in fixes that.\n\nPick a time, maybe after dinner or before bed, and keep phones away. Each of you gets about five minutes. Share one high point and one low point from your day, and one thing you need tomorrow.\n\nThe rule is simple: the listener doesn't fix, defend or compare. You only reflect back what you heard, like 'So work was heavy today and you want a quiet evening.'\n\nTen minutes feels small, but done daily it builds the feeling that you are on the same team. Start tonight and keep it for a month."},
            {"🌙", "Small rituals that keep love alive", "Habits", "3",
                    "Big gestures are lovely, but love lives in repeated small things.\n\nTry a goodbye kiss that lasts a few seconds. Send a good-morning message that isn't about logistics. Cook or order the same comfort meal every Friday. Take a ten-minute walk after dinner with no phones.\n\nRituals tell your brain that this relationship is stable and special. They also give you something to fall back on when life gets busy or stressful.\n\nPick two rituals you can keep without effort and make them non-negotiable. Consistency matters more than creativity."},
            {"🎧", "How to really listen", "Communication", "4",
                    "Listening is the most underrated relationship skill, and it can be practiced.\n\nFirst, stop what you're doing and face your partner. Second, let them finish without planning your reply. Third, repeat back the feeling, not just the facts: 'It sounds like you felt ignored.' Fourth, ask 'Do you want advice, or do you want me to just be here?'\n\nThat last question avoids a lot of arguments, because sometimes people only need to be heard.\n\nIf you notice your mind racing to defend yourself, take a slow breath and come back to curiosity. Understanding someone is not agreeing with them."},
            {"🤝", "Fighting fair: rules that protect you both", "Conflict", "4",
                    "Every couple argues. What matters is how you do it.\n\nUse 'I' statements: 'I felt hurt when the plan changed' lands better than 'You always ruin things.' Stay on the one issue in front of you and leave the past out. Agree on a pause word that either of you can use when things get heated, and take twenty minutes to cool down before returning.\n\nAvoid sarcasm, name-calling and the silent treatment. They create distance that lasts long after the topic is forgotten.\n\nEnd every disagreement with repair: a hug, an apology for your part, and one thing you'll both try differently."},
            {"🏝", "Long distance without the lonely", "Distance", "4",
                    "Distance is hard, but it can also make couples communicate better than most.\n\nSet a rhythm you both like: a daily voice note, a weekly video date, and a countdown to your next visit. Do something at the same time, like watching the same episode or cooking the same recipe.\n\nShare the boring parts of your day too. Photos of your lunch or your commute make you feel present in each other's lives.\n\nTalk openly about expectations, such as how often to call and how to handle busy weeks. Having a next date in the calendar is the best antidote to missing someone."},
            {"💌", "Love languages in plain words", "Connection", "3",
                    "The idea of love languages, popularised by Gary Chapman, is a handy way to talk about how people feel cared for.\n\nSome feel loved through words, others through quality time, thoughtful gifts, helpful acts or physical touch. Most of us like a mix, with one or two that matter most.\n\nInstead of guessing, ask each other: 'What makes you feel most cared for?' and 'What small thing could I do this week?'\n\nTreat it as a conversation starter, not a label. The goal is to give love in the way your partner can actually feel it."},
            {"🌱", "Growing together without losing yourself", "Growth", "4",
                    "Healthy couples are two whole people, not two halves.\n\nKeep your own friends, hobbies and goals, and cheer for each other's. Share what you're learning, because growth gives you new things to talk about and keeps the relationship fresh.\n\nTalk about the future regularly: where you want to live, how you'll handle money, what you want in five years. These conversations feel serious, but they prevent surprises later.\n\nIt's fine to need space sometimes. Saying 'I need an hour alone and then I'd love to catch up' is respectful and keeps closeness safe."},
            {"🎬", "Date ideas that cost almost nothing", "Fun", "2",
                    "Great dates are about attention, not money.\n\nTry a sunset walk with one rule: no phones. Cook a dish neither of you has made before. Have a living-room picnic with candles. Make a playlist of songs that remind you of each other and listen together. Visit a place from your first month together. Write each other a short letter and read them aloud.\n\nBook the next date before this one ends, so there's always something to look forward to. Take photos or record a short vlog in UsTwo and add it to your memories."}};

    private int[] todaysArticles() {
        Calendar c = Calendar.getInstance();
        long seed = c.get(Calendar.DAY_OF_YEAR) * 31L + c.get(Calendar.YEAR) + articleSeed * 7919L;
        List<Integer> idx = new ArrayList<>();
        for (int i = 0; i < ARTICLES.length; i++) idx.add(i);
        Collections.shuffle(idx, new Random(seed));
        return new int[]{idx.get(0), idx.get(1), idx.get(2)};
    }
    private View articleCard(final int i) {
        String[] a = ARTICLES[i];
        LinearLayout r = row(); r.setBackground(shape(CARD, 18)); r.setPadding(dp(12), dp(12), dp(14), dp(12)); r.setElevation(dp(1));
        TextView em = text(a[0], 26, TEXT, false); em.setGravity(Gravity.CENTER); em.setBackground(shape(ACCENT, 14));
        r.addView(em, new LinearLayout.LayoutParams(dp(54), dp(54)));
        LinearLayout c = col(); c.setPadding(dp(12), 0, 0, 0);
        c.addView(text(a[1], 15, TEXT, true));
        c.addView(text(a[2] + "  •  " + a[3] + " min read", 12, GRAY, false), lp(-2, -2, 3));
        r.addView(c, new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(text("›", 22, GRAY, false));
        tapable(r, () -> showArticle(i));
        return r;
    }
    private void showArticle(final int i) {
        String[] a = ARTICLES[i];
        LinearLayout p = col(); p.setPadding(dp(22), dp(14), dp(22), dp(28)); p.setBackgroundColor(BG);
        TextView bk = text("←", 28, TEXT, false); tapable(bk, () -> go(tab)); p.addView(bk);
        TextView em = text(a[0], 40, TEXT, false); p.addView(em, lp(-2, -2, 12));
        p.addView(text(a[1], 26, TEXT, true), lp(-2, -2, 8));
        p.addView(text(a[2] + "  •  " + a[3] + " min read", 13, PINK, true), lp(-2, -2, 6));
        TextView body = text(a[4], 16, TEXT, false); body.setLineSpacing(dp(5), 1f);
        p.addView(body, lp(-1, -2, 18));
        p.addView(pill("Next article  →", PINK, Color.WHITE, 0, () -> showArticle((i + 1) % ARTICLES.length)), lp(-1, dp(52), 26));
        push(scroll(p));
    }
    private void showAllArticles() {
        LinearLayout p = col(); p.setPadding(dp(18), dp(14), dp(18), dp(24)); p.setBackgroundColor(BG);
        TextView bk = text("←", 28, TEXT, false); tapable(bk, () -> go(tab)); p.addView(bk);
        p.addView(text("Read together", 26, TEXT, true), lp(-2, -2, 8));
        p.addView(text("Short reads for the two of you", 13, GRAY, false), lp(-2, -2, 2));
        for (int i = 0; i < ARTICLES.length; i++) p.addView(articleCard(i), lp(-1, -2, 12));
        push(scroll(p));
    }

    // =====================================================================
    //  Home
    // =====================================================================
    private String greeting() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return h < 12 ? "Good Morning" : h < 17 ? "Good Afternoon" : "Good Evening";
    }
    private LinearLayout headerRow(String title, String action, final Runnable r) {
        LinearLayout h = row(); h.setPadding(0, dp(22), 0, dp(10));
        h.addView(text(title, 17, TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        if (action != null) { TextView a = text(action, 13, PINK, true); a.setPadding(dp(8), dp(4), 0, dp(4)); tapable(a, r); h.addView(a); }
        return h;
    }
    private void pickTogetherDate() {
        Calendar c = Calendar.getInstance();
        long s = sp.getLong("since", 0); if (s > 0) c.setTimeInMillis(s);
        new DatePickerDialog(this, (view, y, mo, d) -> {
            Calendar x = Calendar.getInstance(); x.set(y, mo, d, 0, 0, 0);
            long t = x.getTimeInMillis(); sp.edit().putLong("since", t).apply();
            FirebaseUser u = auth.getCurrentUser();
            if (u != null) { Map<String, Object> mm = new HashMap<>(); mm.put("togetherSince", t); db.collection("profiles").document(u.getUid()).set(mm, SetOptions.merge()); }
            go(tab);
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private View buildHome() {
        ScrollView sv = new ScrollView(this); sv.setBackgroundColor(BG); sv.setVerticalScrollBarEnabled(false);
        LinearLayout p = col(); p.setPadding(dp(18), dp(14), dp(18), dp(28)); sv.addView(p);
        FirebaseUser u = auth.getCurrentUser();
        // header
        LinearLayout h = row();
        LinearLayout hl = col();
        hl.addView(text(greeting(), 24, TEXT, true));
        hl.addView(text("Together is our favorite place ♡", 13, GRAY, false), lp(-2, -2, 2));
        h.addView(hl, new LinearLayout.LayoutParams(0, -2, 1f));
        String initial = (u != null && u.getEmail() != null && !u.getEmail().isEmpty()) ? u.getEmail().substring(0, 1).toUpperCase(Locale.US) : "♡";
        TextView av = avatar(initial, 40); tapable(av, () -> go(4)); h.addView(av);
        p.addView(h); fadeIn(h, 0);
        // together card
        long since = sp.getLong("since", 0);
        LinearLayout card = row(); card.setPadding(dp(20), dp(18), dp(20), dp(18)); card.setElevation(dp(4));
        GradientDrawable cg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{PINK, mix(PINK, dark ? Color.parseColor("#6D3BC9") : Color.parseColor("#C9A2FF"), 0.55f)});
        cg.setCornerRadius(dp(22)); card.setBackground(cg);
        LinearLayout cl = col();
        cl.addView(text("Together for", 13, Color.WHITE, false));
        if (since > 0) {
            long days = Math.max(0, (System.currentTimeMillis() - since) / 86400000L);
            cl.addView(text(days + (days == 1 ? " day" : " days"), 36, Color.WHITE, true), lp(-2, -2, 2));
            cl.addView(text("since " + fmtDate(since), 12, Color.WHITE, false), lp(-2, -2, 2));
        } else {
            cl.addView(text("Set your day ♡", 28, Color.WHITE, true), lp(-2, -2, 2));
            cl.addView(text("Tap to choose the date you got together", 12, Color.WHITE, false), lp(-2, -2, 2));
        }
        card.addView(cl, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView bigHeart = text("♥", 64, Color.argb(200, 255, 255, 255), false); card.addView(bigHeart);
        tapable(card, this::pickTogetherDate);
        p.addView(card, lp(-1, -2, 18)); fadeIn(card, 60);
        bigHeart.animate().scaleX(1.12f).scaleY(1.12f).setDuration(900).withEndAction(() -> bigHeart.animate().scaleX(1f).scaleY(1f).setDuration(900).start()).start();
        // quick actions
        LinearLayout qa = row(); qa.setPadding(0, dp(18), 0, 0);
        String[] qi = {"🖼", "⏳", "📅", "📝"};
        String[] ql = {"Memories", "Timeline", "Dates", "Notes"};
        for (int i = 0; i < 4; i++) {
            final int n = i;
            LinearLayout c = col(); c.setGravity(Gravity.CENTER_HORIZONTAL);
            TextView ic = text(qi[i], 24, TEXT, false); ic.setGravity(Gravity.CENTER); ic.setBackground(shape(ACCENT, 20));
            c.addView(ic, new LinearLayout.LayoutParams(dp(58), dp(58)));
            TextView lb = text(ql[i], 12, TEXT, false); lb.setGravity(Gravity.CENTER); c.addView(lb, lp(-2, -2, 6));
            tapable(c, () -> { if (n == 0) go(3); else if (n == 1) showListScreen("Our Timeline", "timeline", 0); else if (n == 2) showListScreen("Special Dates", "dates", 1); else showListScreen("Shared Notes", "notes", 2); });
            qa.addView(c, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        p.addView(qa); fadeIn(qa, 120);
        // daily message
        Calendar cal = Calendar.getInstance();
        String q = QUOTES[(cal.get(Calendar.DAY_OF_YEAR) + cal.get(Calendar.YEAR)) % QUOTES.length];
        TextView qt = text("✨  " + q, 14, TEXT, false); qt.setLineSpacing(dp(3), 1f); qt.setPadding(dp(16), dp(14), dp(16), dp(14)); qt.setBackground(shape(ACCENT, 18));
        p.addView(qt, lp(-1, -2, 20)); fadeIn(qt, 180);
        // recent memories (from this phone)
        p.addView(headerRow("Recent Memories", "View all", () -> go(3)));
        List<Media> media = queryMedia();
        HorizontalScrollView hs = new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false);
        LinearLayout hr = row(); hs.addView(hr);
        if (media.isEmpty()) {
            TextView t = text("Your photos and vlogs will show up here. Tap the camera to make the first one 💗", 13, GRAY, false);
            hr.addView(t);
        }
        for (int i = 0; i < Math.min(10, media.size()); i++) {
            final Media m = media.get(i);
            FrameLayout f = new FrameLayout(this); f.setBackground(shape(LIGHT, 16)); clipRound(f, 16);
            ImageView iv = new ImageView(this); iv.setScaleType(ImageView.ScaleType.CENTER_CROP); f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            loadLocalThumb(m.uri, iv, 360);
            if (m.video) { TextView pl = text("▶", 12, Color.WHITE, false); pl.setGravity(Gravity.CENTER); pl.setBackground(oval(Color.argb(120, 0, 0, 0))); f.addView(pl, new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER)); }
            tapable(f, () -> {
                if (m.video) showPlayer(m.uri, true, this::enterApp);
                else { Intent it = new Intent(Intent.ACTION_VIEW); it.setDataAndType(m.uri, "image/*"); it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); try { startActivity(it); } catch (Exception e) { toast("No photo viewer found."); } }
            });
            LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(dp(104), dp(136)); fp.rightMargin = dp(10);
            hr.addView(f, fp);
        }
        p.addView(hs);
        // articles
        p.addView(headerRow("Read together", "See all", this::showAllArticles));
        int[] today = todaysArticles();
        for (int k = 0; k < 3; k++) p.addView(articleCard(today[k]), lp(-1, -2, k == 0 ? 0 : 10));
        TextView shuffle = text("🔀  Shuffle articles", 13, PINK, true); shuffle.setGravity(Gravity.CENTER); shuffle.setPadding(0, dp(12), 0, dp(4));
        tapable(shuffle, () -> { articleSeed++; go(0); });
        p.addView(shuffle);
        // vlog feed
        p.addView(headerRow("Latest vlogs", null, null));
        LinearLayout feed = col(); p.addView(feed);
        loadFeed(feed);
        return sv;
    }

    // =====================================================================
    //  Chat (photos, voice notes, hearts) and shared lists
    // =====================================================================
    private String pairId() {
        String me = auth.getCurrentUser().getUid();
        String o = (partnerUid == null || partnerUid.isEmpty()) ? "solo" : partnerUid;
        return me.compareTo(o) < 0 ? me + "_" + o : o + "_" + me;
    }
    private void stopChat() {
        if (chatReg != null) { chatReg.remove(); chatReg = null; }
        bubbleMap.clear(); chatFirst = true;
        if (chatRecording) finishVoiceNote(false);
        if (vp != null) { try { vp.release(); } catch (Exception ignored) { } vp = null; vpBtn = null; }
    }
    private final ActivityResultLauncher<String> chatImagePicker = registerForActivityResult(
            new ActivityResultContracts.GetContent(), uri -> { if (uri != null) sendChatImage(uri); });

    private View buildChat() {
        final FirebaseUser u = auth.getCurrentUser();
        if (u == null || partnerUid == null || partnerUid.isEmpty()) {
            LinearLayout c = col(); c.setBackgroundColor(BG); c.setGravity(Gravity.CENTER); c.setPadding(dp(32), dp(40), dp(32), dp(40));
            c.addView(text("💌", 60, TEXT, false));
            TextView t = text("Chat with your partner", 22, TEXT, true); t.setGravity(Gravity.CENTER); c.addView(t, lp(-2, -2, 12));
            TextView m = text("Link your partner in Profile first. Then you can send messages, photos, voice notes and hearts here.", 14, GRAY, false);
            m.setGravity(Gravity.CENTER); c.addView(m, lp(-2, -2, 8));
            c.addView(pill("Link partner", PINK, Color.WHITE, 0, () -> go(4)), lp(-1, dp(52), 24));
            return c;
        }
        LinearLayout root = col(); root.setBackgroundColor(BG);
        LinearLayout h = row(); h.setPadding(dp(18), dp(12), dp(18), dp(10)); h.setBackgroundColor(NAV); h.setElevation(dp(2));
        h.addView(avatar("♥", 40));
        LinearLayout hc = col(); hc.setPadding(dp(12), 0, 0, 0);
        hc.addView(text("You & Me ♡", 17, TEXT, true));
        hc.addView(text("Private chat • double-tap a message to send a heart", 11, GRAY, false));
        h.addView(hc, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(h);
        chatScroll = new ScrollView(this); chatScroll.setVerticalScrollBarEnabled(false);
        chatList = col(); chatList.setPadding(dp(12), dp(8), dp(12), dp(8)); chatScroll.addView(chatList);
        root.addView(chatScroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        // input bar
        LinearLayout bar = col(); bar.setBackgroundColor(NAV); bar.setPadding(dp(10), dp(8), dp(10), dp(8));
        chatNormalRow = row();
        TextView photo = text("📷", 22, TEXT, false); photo.setPadding(dp(6), dp(6), dp(10), dp(6));
        tapable(photo, () -> chatImagePicker.launch("image/*"));
        chatNormalRow.addView(photo);
        chatInput = field("Message…", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        chatInput.setPadding(dp(14), dp(10), dp(14), dp(10));
        chatNormalRow.addView(chatInput, new LinearLayout.LayoutParams(0, -2, 1f));
        actionBtn = text("🎙", 20, Color.WHITE, true); actionBtn.setGravity(Gravity.CENTER); actionBtn.setBackground(oval(PINK));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(dp(44), dp(44)); ap.leftMargin = dp(8);
        chatNormalRow.addView(actionBtn, ap);
        tapable(actionBtn, () -> {
            String t = chatInput.getText().toString().trim();
            if (!t.isEmpty()) { Map<String, Object> m = new HashMap<>(); m.put("type", "text"); m.put("text", t); sendMessage(m); chatInput.setText(""); }
            else startVoiceNote();
        });
        chatInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b2, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b2, int c) { actionBtn.setText(s.toString().trim().isEmpty() ? "🎙" : "➤"); }
            @Override public void afterTextChanged(Editable e) { }
        });
        bar.addView(chatNormalRow);
        chatRecRow = row(); chatRecRow.setVisibility(View.GONE);
        chatRecLabel = text("● Recording 0:00", 15, PINK, true);
        chatRecRow.addView(chatRecLabel, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView cancel = text("✕  Cancel", 14, GRAY, true); cancel.setPadding(dp(12), dp(10), dp(14), dp(10));
        tapable(cancel, () -> finishVoiceNote(false));
        chatRecRow.addView(cancel);
        TextView send = text("➤", 20, Color.WHITE, true); send.setGravity(Gravity.CENTER); send.setBackground(oval(PINK));
        tapable(send, () -> finishVoiceNote(true));
        chatRecRow.addView(send, new LinearLayout.LayoutParams(dp(44), dp(44)));
        bar.addView(chatRecRow);
        root.addView(bar);
        listenChat(u.getUid());
        return root;
    }

    private void listenChat(final String me) {
        chatFirst = true;
        chatReg = db.collection("couples").document(pairId()).collection("messages").orderBy("createdAt").limitToLast(150)
                .addSnapshotListener((qs, err) -> {
                    if (err != null) { toast("Chat couldn't load: " + err.getMessage()); return; }
                    if (qs == null || chatList == null) return;
                    boolean added = false;
                    for (DocumentChange ch : qs.getDocumentChanges()) {
                        DocumentSnapshot d = ch.getDocument();
                        if (ch.getType() == DocumentChange.Type.ADDED) {
                            View b = bubble(d, me); bubbleMap.put(d.getId(), b); chatList.addView(b); added = true;
                            if (!chatFirst && !me.equals(d.getString("from"))) incomingSound();
                        } else if (ch.getType() == DocumentChange.Type.MODIFIED) {
                            View old = bubbleMap.get(d.getId());
                            if (old != null) { int ix = chatList.indexOfChild(old); chatList.removeViewAt(ix); View nb = bubble(d, me); nb.setAlpha(1f); nb.setTranslationY(0f); bubbleMap.put(d.getId(), nb); chatList.addView(nb, ix); }
                        } else if (ch.getType() == DocumentChange.Type.REMOVED) {
                            View old = bubbleMap.remove(d.getId()); if (old != null) chatList.removeView(old);
                        }
                    }
                    chatFirst = false;
                    if (added) chatScroll.post(() -> chatScroll.fullScroll(View.FOCUS_DOWN));
                });
    }
    private void incomingSound() {
        if (!soundOn) return;
        try { new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 55).startTone(ToneGenerator.TONE_PROP_ACK, 140); } catch (Exception ignored) { }
    }

    private View bubble(final DocumentSnapshot d, final String me) {
        final boolean mine = me.equals(d.getString("from"));
        String type = d.getString("type"); if (type == null) type = "text";
        LinearLayout wrap = col(); wrap.setGravity(mine ? Gravity.END : Gravity.START);
        View body; Runnable single = null;
        if (type.equals("image")) {
            FrameLayout f = new FrameLayout(this); f.setBackground(shape(LIGHT, 18)); clipRound(f, 18);
            ImageView iv = new ImageView(this); iv.setScaleType(ImageView.ScaleType.CENTER_CROP); f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            final String url = d.getString("url"); if (url != null) loadImage(url, iv);
            f.setLayoutParams(new LinearLayout.LayoutParams(dp(220), dp(270)));
            body = f; single = () -> { if (url != null) showImageViewer(url); };
        } else if (type.equals("voice")) {
            LinearLayout v = row(); v.setPadding(dp(12), dp(10), dp(16), dp(10)); v.setBackground(shape(mine ? PINK : CARD, 20));
            final TextView pl = text("▶", 16, mine ? PINK : Color.WHITE, true); pl.setGravity(Gravity.CENTER); pl.setBackground(oval(mine ? Color.WHITE : PINK));
            v.addView(pl, new LinearLayout.LayoutParams(dp(34), dp(34)));
            TextView bars = text("▂▃▅▇▅▃▂▃▅▃▂", 16, mine ? Color.WHITE : PINK, false); bars.setPadding(dp(10), 0, dp(10), 0); v.addView(bars);
            v.addView(text(fmt(num(d, "durMs")), 12, mine ? Color.WHITE : GRAY, true));
            final String url = d.getString("url");
            body = v; single = () -> { if (url != null) playVoice(url, pl); };
        } else {
            TextView t = text(d.getString("text") == null ? "" : d.getString("text"), 15, mine ? Color.WHITE : TEXT, false);
            t.setPadding(dp(14), dp(9), dp(14), dp(9)); t.setBackground(shape(mine ? PINK : CARD, 18)); t.setMaxWidth(dp(270));
            body = t;
        }
        wrap.addView(body);
        List<?> lb = (List<?>) d.get("likedBy");
        final boolean liked = lb != null && lb.contains(me);
        if (lb != null && !lb.isEmpty()) {
            TextView hh = text("♥ " + lb.size(), 12, PINK, true); hh.setPadding(dp(6), dp(2), dp(6), 0); wrap.addView(hh);
        }
        wrap.addView(text(new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date(num(d, "createdAt"))), 10, GRAY, false));
        final Runnable fs = single;
        final View bodyView = body;
        final GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) { if (fs != null) fs.run(); return true; }
            @Override public boolean onDoubleTap(MotionEvent e) {
                if (soundOn) bodyView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                d.getReference().update("likedBy", liked ? FieldValue.arrayRemove(me) : FieldValue.arrayUnion(me));
                return true;
            }
        });
        body.setOnTouchListener((x, e) -> gd.onTouchEvent(e));
        LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(-1, -2); wl.topMargin = dp(8); wrap.setLayoutParams(wl);
        fadeIn(wrap, 0);
        return wrap;
    }
    private void sendMessage(Map<String, Object> extra) {
        FirebaseUser u = auth.getCurrentUser(); if (u == null) return;
        Map<String, Object> m = new HashMap<>(extra);
        m.put("from", u.getUid()); m.put("createdAt", System.currentTimeMillis()); m.put("likedBy", new ArrayList<String>());
        db.collection("couples").document(pairId()).collection("messages").add(m)
                .addOnFailureListener(e -> toast("Couldn't send: " + e.getMessage()));
        if (soundOn && chatList != null) chatList.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
    }
    private void sendChatImage(final Uri uri) {
        final FirebaseUser u = auth.getCurrentUser(); if (u == null) return;
        toast("Sending photo…");
        io.execute(() -> {
            try {
                BitmapFactory.Options b = new BitmapFactory.Options(); b.inJustDecodeBounds = true;
                try (InputStream i1 = getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(i1, null, b); }
                int sample = 1; while (Math.max(b.outWidth, b.outHeight) / sample > 1600) sample *= 2;
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inSampleSize = sample;
                Bitmap bm;
                try (InputStream i2 = getContentResolver().openInputStream(uri)) { bm = BitmapFactory.decodeStream(i2, null, o); }
                if (bm == null) { runOnUiThread(() -> toast("Couldn't read that photo.")); return; }
                int rot = 0;
                try (InputStream i3 = getContentResolver().openInputStream(uri)) {
                    ExifInterface ex = new ExifInterface(i3);
                    int or = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    rot = or == ExifInterface.ORIENTATION_ROTATE_90 ? 90 : or == ExifInterface.ORIENTATION_ROTATE_180 ? 180 : or == ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
                } catch (Exception ignored) { }
                if (rot != 0) { Matrix mx = new Matrix(); mx.postRotate(rot); bm = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), mx, true); }
                ByteArrayOutputStream bo = new ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.JPEG, 82, bo);
                final byte[] bytes = bo.toByteArray();
                final StorageReference ref = storage.getReference().child("users/" + u.getUid() + "/chat/" + System.currentTimeMillis() + ".jpg");
                runOnUiThread(() -> ref.putBytes(bytes).addOnSuccessListener(t -> ref.getDownloadUrl().addOnSuccessListener(url -> {
                    Map<String, Object> m = new HashMap<>(); m.put("type", "image"); m.put("url", url.toString()); sendMessage(m);
                })).addOnFailureListener(e -> toast("Photo failed: " + e.getMessage())));
            } catch (Exception e) { runOnUiThread(() -> toast("Couldn't send that photo.")); }
        });
    }
    private void startVoiceNote() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { micPerm.launch(Manifest.permission.RECORD_AUDIO); return; }
        try {
            chatRecFile = new File(getCacheDir(), "vn_" + System.currentTimeMillis() + ".m4a");
            chatRec = new MediaRecorder();
            chatRec.setAudioSource(MediaRecorder.AudioSource.MIC);
            chatRec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            chatRec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            chatRec.setOutputFile(chatRecFile.getAbsolutePath());
            chatRec.prepare(); chatRec.start();
            chatRecording = true; chatRecStart = System.currentTimeMillis();
            chatNormalRow.setVisibility(View.GONE); chatRecRow.setVisibility(View.VISIBLE);
            if (soundOn) chatRecRow.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            final Runnable[] t = new Runnable[1];
            t[0] = () -> { if (!chatRecording) return; chatRecLabel.setText("● Recording " + fmt(System.currentTimeMillis() - chatRecStart)); main.postDelayed(t[0], 300); };
            main.post(t[0]);
        } catch (Exception e) { chatRecording = false; toast("Couldn't start recording: " + e.getMessage()); }
    }
    private void finishVoiceNote(boolean send) {
        if (!chatRecording) return;
        chatRecording = false;
        long dur = System.currentTimeMillis() - chatRecStart;
        try { chatRec.stop(); } catch (Exception e) { send = false; }
        try { chatRec.release(); } catch (Exception ignored) { }
        chatRec = null;
        if (chatNormalRow != null) chatNormalRow.setVisibility(View.VISIBLE);
        if (chatRecRow != null) chatRecRow.setVisibility(View.GONE);
        if (!send || dur < 800 || chatRecFile == null) { if (send) toast("Hold on a little longer to record."); return; }
        final FirebaseUser u = auth.getCurrentUser(); if (u == null) return;
        final long durMs = dur;
        final StorageReference ref = storage.getReference().child("users/" + u.getUid() + "/chat/" + System.currentTimeMillis() + ".m4a");
        toast("Sending voice note…");
        ref.putFile(Uri.fromFile(chatRecFile)).addOnSuccessListener(t -> ref.getDownloadUrl().addOnSuccessListener(url -> {
            Map<String, Object> m = new HashMap<>(); m.put("type", "voice"); m.put("url", url.toString()); m.put("durMs", durMs); sendMessage(m);
        })).addOnFailureListener(e -> toast("Voice note failed: " + e.getMessage()));
    }
    private void playVoice(String url, final TextView btn) {
        try {
            if (vp != null) { boolean same = vpBtn == btn; vp.release(); vp = null; if (vpBtn != null) vpBtn.setText("▶"); vpBtn = null; if (same) return; }
            vp = new MediaPlayer(); vpBtn = btn;
            vp.setDataSource(url);
            vp.setOnPreparedListener(mp -> { btn.setText("❚❚"); mp.start(); });
            vp.setOnCompletionListener(mp -> { btn.setText("▶"); });
            vp.setOnErrorListener((mp, w, x) -> { btn.setText("▶"); toast("Couldn't play that voice note."); return true; });
            vp.prepareAsync();
        } catch (Exception e) { toast("Couldn't play that voice note."); }
    }
    private void showImageViewer(String url) {
        stopChat(); lightBars(false);
        FrameLayout f = new FrameLayout(this); f.setBackgroundColor(Color.BLACK);
        ImageView iv = new ImageView(this); iv.setScaleType(ImageView.ScaleType.FIT_CENTER); f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        loadImage(url, iv);
        TextView x = text("←", 28, Color.WHITE, false); x.setPadding(dp(18), dp(14), dp(18), dp(14));
        x.setOnClickListener(v -> { tab = 1; enterApp(); }); f.addView(x, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START));
        back = () -> { tab = 1; enterApp(); };
        setContentView(f); applyInsets(f, true, true);
    }

    // ---- shared timeline / dates / notes (stored under couples/<pair>/...)
    private void showListScreen(final String title, final String coll, final int kind) {
        LinearLayout p = col(); p.setBackgroundColor(BG); p.setPadding(dp(18), dp(14), dp(18), 0);
        LinearLayout h = row();
        TextView bk = text("←", 28, TEXT, false); tapable(bk, () -> go(tab)); h.addView(bk);
        TextView ttl = text(title, 20, TEXT, true); ttl.setGravity(Gravity.CENTER); h.addView(ttl, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView add = text("＋", 28, PINK, true); tapable(add, () -> addEntryDialog(title, coll, kind)); h.addView(add);
        p.addView(h);
        final LinearLayout list = col(); list.setPadding(0, dp(10), 0, dp(24));
        ScrollView sv = new ScrollView(this); sv.addView(list); sv.setVerticalScrollBarEnabled(false);
        p.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        push(p);
        String hint = kind == 0 ? "Add the moments that made your story: first met, first date, first trip…" : kind == 1 ? "Add birthdays, anniversaries and days you never want to forget." : "Write notes you both can read: things you love, plans, little reminders.";
        list.addView(text("Loading…", 13, GRAY, false));
        db.collection("couples").document(pairId()).collection(coll).get().addOnSuccessListener(qs -> {
            list.removeAllViews();
            List<DocumentSnapshot> docs = new ArrayList<>(qs.getDocuments());
            if (docs.isEmpty()) { TextView t = text(hint, 14, GRAY, false); t.setGravity(Gravity.CENTER); t.setPadding(dp(20), dp(40), dp(20), 0); list.addView(t); return; }
            final long now = System.currentTimeMillis();
            if (kind == 0) Collections.sort(docs, (a, b2) -> Long.compare(num(a, "date"), num(b2, "date")));
            else if (kind == 1) Collections.sort(docs, (a, b2) -> Long.compare(daysUntil(num(a, "date"), now), daysUntil(num(b2, "date"), now)));
            else Collections.sort(docs, (a, b2) -> Long.compare(num(b2, "createdAt"), num(a, "createdAt")));
            int n = 0;
            for (final DocumentSnapshot d : docs) {
                LinearLayout c = row(); c.setBackground(shape(CARD, 18)); c.setPadding(dp(14), dp(14), dp(14), dp(14)); c.setElevation(dp(1));
                View bar = new View(this); bar.setBackground(shape(PINK, 3)); c.addView(bar, new LinearLayout.LayoutParams(dp(4), dp(40)));
                LinearLayout tx = col(); tx.setPadding(dp(12), 0, 0, 0);
                String t = d.getString("title"); tx.addView(text(t == null || t.isEmpty() ? "Untitled" : t, 15, TEXT, true));
                if (kind == 2) { String b3 = d.getString("body"); if (b3 != null && !b3.isEmpty()) { TextView bt = text(b3, 14, TEXT, false); bt.setLineSpacing(dp(2), 1f); tx.addView(bt, lp(-2, -2, 4)); } }
                else tx.addView(text("📅  " + fmtDate(num(d, "date")), 12, GRAY, false), lp(-2, -2, 3));
                c.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
                if (kind == 1) {
                    long dd = daysUntil(num(d, "date"), now);
                    TextView chip = text(dd == 0 ? "Today 🎉" : "In " + dd + " days", 12, PINK, true); chip.setPadding(dp(12), dp(6), dp(12), dp(6)); chip.setBackground(shape(ACCENT, 14)); c.addView(chip);
                }
                c.setOnLongClickListener(v -> {
                    new AlertDialog.Builder(this).setTitle("Delete this?").setPositiveButton("Delete", (dlg, w) -> d.getReference().delete().addOnSuccessListener(x -> showListScreen(title, coll, kind))).setNegativeButton("Cancel", null).show();
                    return true;
                });
                list.addView(c, lp(-1, -2, 10)); fadeIn(c, 40 * Math.min(n++, 8));
            }
        }).addOnFailureListener(e -> { list.removeAllViews(); list.addView(text("Couldn't load: " + e.getMessage() + "\n\nCheck that the Firestore rules are published.", 13, GRAY, false)); });
    }
    private long daysUntil(long date, long now) {
        Calendar d = Calendar.getInstance(); d.setTimeInMillis(date);
        Calendar n = Calendar.getInstance(); n.setTimeInMillis(now); n.set(Calendar.HOUR_OF_DAY, 0); n.set(Calendar.MINUTE, 0); n.set(Calendar.SECOND, 0); n.set(Calendar.MILLISECOND, 0);
        Calendar t = Calendar.getInstance(); t.set(n.get(Calendar.YEAR), d.get(Calendar.MONTH), d.get(Calendar.DAY_OF_MONTH), 0, 0, 0); t.set(Calendar.MILLISECOND, 0);
        if (t.before(n)) t.add(Calendar.YEAR, 1);
        return (t.getTimeInMillis() - n.getTimeInMillis()) / 86400000L;
    }
    private void addEntryDialog(final String title, final String coll, final int kind) {
        LinearLayout box = col(); box.setPadding(dp(22), dp(10), dp(22), 0);
        final EditText t = new EditText(this); t.setHint(kind == 2 ? "Title" : kind == 1 ? "What's the occasion?" : "What happened?"); box.addView(t);
        final long[] when = {System.currentTimeMillis()};
        final EditText body = new EditText(this); body.setHint("Write something sweet…"); body.setMinLines(3);
        final TextView dateBtn = text("📅  " + fmtDate(when[0]), 15, PINK, true); dateBtn.setPadding(0, dp(16), 0, dp(8));
        if (kind == 2) box.addView(body);
        else {
            box.addView(dateBtn);
            dateBtn.setOnClickListener(v -> {
                Calendar c = Calendar.getInstance(); c.setTimeInMillis(when[0]);
                new DatePickerDialog(this, (view, y, mo, d) -> { Calendar x = Calendar.getInstance(); x.set(y, mo, d, 12, 0, 0); when[0] = x.getTimeInMillis(); dateBtn.setText("📅  " + fmtDate(when[0])); },
                        c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
            });
        }
        new AlertDialog.Builder(this).setTitle("Add to " + title).setView(box)
                .setPositiveButton("Save", (dlg, w) -> {
                    Map<String, Object> m = new HashMap<>();
                    m.put("title", t.getText().toString().trim()); m.put("createdAt", System.currentTimeMillis());
                    if (kind == 2) m.put("body", body.getText().toString().trim()); else m.put("date", when[0]);
                    db.collection("couples").document(pairId()).collection(coll).add(m)
                            .addOnSuccessListener(x -> showListScreen(title, coll, kind))
                            .addOnFailureListener(e -> toast("Couldn't save: " + e.getMessage()));
                }).setNegativeButton("Cancel", null).show();
    }

    // =====================================================================
    //  Profile, themes and settings
    // =====================================================================
    private View buildProfile() {
        LinearLayout p = col(); p.setPadding(dp(20), dp(16), dp(20), dp(28)); p.setBackgroundColor(BG);
        final FirebaseUser u = auth.getCurrentUser();
        p.addView(text("Profile", 26, TEXT, true));
        if (u == null) {
            p.addView(pill("Log in / Create account", PINK, Color.WHITE, 0, () -> showAuth(true)), lp(-1, dp(52), 20));
            return scroll(p);
        }
        String email = u.getEmail() == null ? "" : u.getEmail();
        LinearLayout head = col(); head.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView av = avatar(email.isEmpty() ? "♡" : email.substring(0, 1).toUpperCase(Locale.US), 76); av.setTextSize(30);
        head.addView(av); head.addView(text(email, 14, TEXT, true), lp(-2, -2, 8));
        p.addView(head, lp(-1, -2, 14));

        // theme chooser
        LinearLayout tc = col(); tc.setBackground(shape(CARD, 18)); tc.setPadding(dp(16), dp(14), dp(16), dp(16));
        tc.addView(text("Appearance", 15, TEXT, true));
        LinearLayout tr = row(); tr.setPadding(0, dp(12), 0, 0);
        String[] tn = {"Blush Pink", "Midnight", "Cream & Rose"};
        int[] sw = {Color.parseColor("#FF8FA3"), Color.parseColor("#A66BFF"), Color.parseColor("#E8807F")};
        int[] bgs = {Color.parseColor("#FFF7F9"), Color.parseColor("#130A24"), Color.parseColor("#FFF6EE")};
        for (int i = 0; i < 3; i++) {
            final int n = i;
            LinearLayout c = col(); c.setGravity(Gravity.CENTER_HORIZONTAL); c.setPadding(dp(6), dp(8), dp(6), dp(8));
            GradientDrawable bgd = shape(i == theme ? ACCENT : Color.TRANSPARENT, 14); if (i == theme) bgd.setStroke(dp(2), PINK); c.setBackground(bgd);
            FrameLayout sf = new FrameLayout(this);
            View big = new View(this); big.setBackground(oval(bgs[i])); sf.addView(big, new FrameLayout.LayoutParams(dp(46), dp(46)));
            View dot = new View(this); dot.setBackground(oval(sw[i])); sf.addView(dot, new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
            GradientDrawable ring = (GradientDrawable) big.getBackground(); ring.setStroke(dp(1), GRAY);
            c.addView(sf, new LinearLayout.LayoutParams(dp(46), dp(46)));
            TextView lb = text(tn[i], 11, TEXT, i == theme); lb.setGravity(Gravity.CENTER); c.addView(lb, lp(-2, -2, 6));
            tapable(c, () -> { sp.edit().putInt("theme", n).apply(); applyTheme(n); buildShell(); enterApp(); });
            tr.addView(c, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        tc.addView(tr);
        p.addView(tc, lp(-1, -2, 16));

        // settings
        LinearLayout st = col(); st.setBackground(shape(CARD, 18)); st.setPadding(dp(16), dp(8), dp(16), dp(8));
        TextView snd = text("Sounds & haptics:  " + (soundOn ? "ON" : "OFF"), 15, TEXT, true); snd.setPadding(0, dp(12), 0, dp(12));
        tapable(snd, () -> { soundOn = !soundOn; sp.edit().putBoolean("sound", soundOn).apply(); go(4); });
        st.addView(snd);
        long since = sp.getLong("since", 0);
        TextView ts = text("Together since:  " + (since > 0 ? fmtDate(since) : "Set the date"), 15, TEXT, true); ts.setPadding(0, dp(12), 0, dp(12));
        tapable(ts, this::pickTogetherDate); st.addView(ts);
        p.addView(st, lp(-1, -2, 14));

        // pairing
        LinearLayout card = col(); card.setBackground(shape(CARD, 18)); card.setPadding(dp(16), dp(14), dp(16), dp(16));
        card.addView(text("Your pairing code", 13, GRAY, false));
        LinearLayout cr = row();
        cr.addView(text(myCode.isEmpty() ? "------" : myCode, 28, PINK, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView copy = text("Copy", 14, PINK, true); copy.setPadding(dp(14), dp(8), dp(14), dp(8)); copy.setBackground(shape(ACCENT, 16));
        tapable(copy, () -> { ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("UsTwo code", myCode)); toast("Code copied."); });
        cr.addView(copy);
        card.addView(cr, lp(-1, -2, 4));
        card.addView(text("Send this to your partner. They enter it below on their phone.", 12, GRAY, false), lp(-2, -2, 4));
        p.addView(card, lp(-1, -2, 14));
        LinearLayout lc = col(); lc.setBackground(shape(CARD, 18)); lc.setPadding(dp(16), dp(14), dp(16), dp(16));
        lc.addView(text("Link partner", 15, TEXT, true));
        final TextView status = text(partnerUid.isEmpty() ? "Not linked yet." : "Linked 💗", 13, GRAY, false);
        lc.addView(status, lp(-2, -2, 4));
        if (!partnerUid.isEmpty()) db.collection("profiles").document(partnerUid).get().addOnSuccessListener(d -> { String pe = d.getString("email"); if (pe != null) status.setText("Linked with " + pe + " 💗"); });
        final EditText code = field("Partner's code", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        lc.addView(code, lp(-1, -2, 10));
        lc.addView(pill("Link partner", PINK, Color.WHITE, 0, () -> linkPartner(code.getText().toString())), lp(-1, dp(48), 10));
        lc.addView(text("You each enter the other's code. Then chat and vlogs work both ways.", 12, GRAY, false), lp(-2, -2, 8));
        p.addView(lc, lp(-1, -2, 14));
        p.addView(pill("📖  All articles", ACCENT, PINK, 0, this::showAllArticles), lp(-1, dp(52), 14));
        p.addView(pill("🎵  Bambi Space (voice memos)", ACCENT, PINK, 0, this::bambiScreen), lp(-1, dp(52), 10));
        p.addView(pill("Sign out", Color.TRANSPARENT, PINK, PINK, () -> { auth.signOut(); partnerUid = ""; myCode = ""; tab = 0; showWelcome(); }), lp(-1, dp(52), 10));
        return scroll(p);
    }

    // =====================================================================
    //  Camera (iOS style: grid, tap-to-focus, exposure, zoom, real filter previews)
    // =====================================================================
    private static final int YELLOW = Color.parseColor("#FFD60A");

    private void requestCamera() {
        boolean cam = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        boolean mic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        if (cam && mic) showCamera();
        else camPerm.launch(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO});
    }
    private TextView iconBtn(String glyph, Runnable r) {
        TextView t = text(glyph, 17, Color.WHITE, true); t.setGravity(Gravity.CENTER); t.setBackground(oval(Color.parseColor("#2C2C2E")));
        tapable(t, r);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(dp(40), dp(40)); lp2.rightMargin = dp(8);
        t.setLayoutParams(lp2);
        return t;
    }
    private ColorMatrix filterMatrix(int i, float strength) {
        float[] f = FILTERS[i];
        float sat = 1 + (f[0] - 1) * strength, con = 1 + (f[1] - 1) * strength, br = f[2] * strength;
        float rm = 1 + (f[3] - 1) * strength, gm = 1 + (f[4] - 1) * strength, bm = 1 + (f[5] - 1) * strength;
        float off = (-0.5f * con + 0.5f) * 255f + br;
        ColorMatrix cm = new ColorMatrix(); cm.setSaturation(sat);
        cm.postConcat(new ColorMatrix(new float[]{con * rm, 0, 0, 0, off, 0, con * gm, 0, 0, off, 0, 0, con * bm, 0, off, 0, 0, 0, 1, 0}));
        return cm;
    }

    private void showCamera() {
        stopChat(); cameraScreen = true; back = this::closeCamera; lightBars(false);
        try { mas.load(MediaActionSound.SHUTTER_CLICK); mas.load(MediaActionSound.START_VIDEO_RECORDING); mas.load(MediaActionSound.STOP_VIDEO_RECORDING); } catch (Exception ignored) { }
        camRoot = new FrameLayout(this); camRoot.setBackgroundColor(Color.BLACK);
        camCol = col(); camRoot.addView(camCol, new FrameLayout.LayoutParams(-1, -1));
        // top bar
        topBar = row(); topBar.setPadding(dp(12), dp(6), dp(4), dp(6)); topBar.setBackgroundColor(Color.BLACK);
        flashBtn = iconBtn("⚡", () -> {
            flashOn = !flashOn;
            if (camera != null && camera.getCameraInfo().hasFlashUnit()) camera.getCameraControl().enableTorch(flashOn);
            else { flashOn = false; toast("Flash isn't available on this camera."); }
            flashBtn.setTextColor(flashOn ? YELLOW : Color.WHITE);
        });
        topBar.addView(flashBtn);
        timerBtn = iconBtn("⏱", () -> {
            timerSec = timerSec == 0 ? 3 : timerSec == 3 ? 10 : 0;
            timerBtn.setText(timerSec == 0 ? "⏱" : timerSec + "s"); timerBtn.setTextColor(timerSec == 0 ? Color.WHITE : YELLOW);
        });
        topBar.addView(timerBtn);
        topBar.addView(iconBtn("▦", () -> { gridOn = !gridOn; gridOverlay.setVisibility(gridOn ? View.VISIBLE : View.GONE); }));
        topBar.addView(iconBtn("✨", () -> { effectsOn = !effectsOn; toast(effectsOn ? "Sparkle effects on" : "Sparkle effects off"); }));
        topBar.addView(iconBtn("◐", this::strengthDialog));
        View sp1 = new View(this); topBar.addView(sp1, new LinearLayout.LayoutParams(0, 1, 1f));
        TextView close = iconBtn("✕", this::closeCamera);
        topBar.addView(close);
        camCol.addView(topBar);
        // preview area
        previewFrame = new FrameLayout(this); previewFrame.setBackgroundColor(Color.BLACK);
        previewView = new PreviewView(this);
        previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        previewFrame.addView(previewView, new FrameLayout.LayoutParams(-1, -1));
        gridOverlay = new View(this) {
            final Paint gp = new Paint();
            { gp.setColor(Color.argb(120, 255, 255, 255)); gp.setStrokeWidth(dp(1)); }
            @Override protected void onDraw(Canvas c) {
                int w = getWidth(), h = getHeight();
                c.drawLine(w / 3f, 0, w / 3f, h, gp); c.drawLine(2 * w / 3f, 0, 2 * w / 3f, h, gp);
                c.drawLine(0, h / 3f, w, h / 3f, gp); c.drawLine(0, 2 * h / 3f, w, 2 * h / 3f, gp);
            }
        };
        previewFrame.addView(gridOverlay, new FrameLayout.LayoutParams(-1, -1));
        GradientDrawable fbg = new GradientDrawable(); fbg.setColor(Color.TRANSPARENT); fbg.setStroke(dp(2), YELLOW);
        focusBox = new View(this); focusBox.setBackground(fbg); focusBox.setVisibility(View.GONE);
        previewFrame.addView(focusBox, new FrameLayout.LayoutParams(dp(76), dp(76), Gravity.TOP | Gravity.START));
        sunLine = new View(this); sunLine.setBackgroundColor(YELLOW); sunLine.setVisibility(View.GONE);
        previewFrame.addView(sunLine, new FrameLayout.LayoutParams(dp(2), dp(110), Gravity.TOP | Gravity.START));
        sunMarker = text("☀", 18, YELLOW, true); sunMarker.setVisibility(View.GONE); sunMarker.setBackgroundColor(Color.BLACK);
        previewFrame.addView(sunMarker, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START));
        // zoom pills
        LinearLayout zr = row(); zr.setBackground(shape(Color.argb(110, 0, 0, 0), 24)); zr.setPadding(dp(4), dp(4), dp(4), dp(4));
        zoomHalf = zoomPill("0.5", 0.5f); zoomOne = zoomPill("1×", 1f); zoomTwo = zoomPill("2×", 2f);
        zr.addView(zoomHalf); zr.addView(zoomOne); zr.addView(zoomTwo);
        FrameLayout.LayoutParams zp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL); zp.bottomMargin = dp(14);
        previewFrame.addView(zr, zp);
        recTimer = text("● 00:00", 14, Color.WHITE, true); recTimer.setVisibility(View.GONE); recTimer.setBackground(shape(Color.parseColor("#FF3B30"), 14)); recTimer.setPadding(dp(12), dp(4), dp(12), dp(4));
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL); rp.topMargin = dp(12);
        previewFrame.addView(recTimer, rp);
        countdownText = text("", 96, Color.WHITE, true); countdownText.setVisibility(View.GONE);
        previewFrame.addView(countdownText, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        flashOverlay = new View(this); flashOverlay.setBackgroundColor(Color.WHITE); flashOverlay.setAlpha(0f);
        previewFrame.addView(flashOverlay, new FrameLayout.LayoutParams(-1, -1));
        final ScaleGestureDetector sgd = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) { setZoomRatio(curZoom * d.getScaleFactor()); return true; }
        });
        final float[] startY = new float[1];
        previewFrame.setOnTouchListener((v, e) -> {
            sgd.onTouchEvent(e);
            if (sgd.isInProgress() || e.getPointerCount() > 1) return true;
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) { startY[0] = e.getY(); focusAt(e.getX(), e.getY()); }
            else if (a == MotionEvent.ACTION_MOVE) { if (focusBox.getVisibility() == View.VISIBLE) adjustExposure(startY[0] - e.getY()); }
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) scheduleHideFocus();
            return true;
        });
        camCol.addView(previewFrame, new LinearLayout.LayoutParams(-1, 0, 1f));
        // filter strip with real previews
        filterStrip = new HorizontalScrollView(this); filterStrip.setHorizontalScrollBarEnabled(false); filterStrip.setBackgroundColor(Color.BLACK);
        LinearLayout chips = new LinearLayout(this); chips.setOrientation(LinearLayout.HORIZONTAL); chips.setPadding(dp(8), dp(8), dp(8), dp(4));
        chipImgs = new ImageView[filterNames.length]; chipFrames = new View[filterNames.length]; chipLabels = new TextView[filterNames.length];
        for (int i = 0; i < filterNames.length; i++) {
            final int n = i;
            LinearLayout c = col(); c.setGravity(Gravity.CENTER_HORIZONTAL); c.setPadding(dp(4), 0, dp(4), 0);
            FrameLayout ring = new FrameLayout(this); ring.setPadding(dp(3), dp(3), dp(3), dp(3));
            FrameLayout inner = new FrameLayout(this); inner.setBackground(shape(Color.parseColor("#2C2C2E"), 12)); clipRound(inner, 12);
            ImageView iv = new ImageView(this); iv.setScaleType(ImageView.ScaleType.CENTER_CROP); inner.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            ring.addView(inner, new FrameLayout.LayoutParams(dp(54), dp(70)));
            c.addView(ring, new LinearLayout.LayoutParams(dp(60), dp(76)));
            TextView lb = text(filterNames[i], 10, Color.WHITE, false); lb.setGravity(Gravity.CENTER); c.addView(lb, lp(-2, -2, 3));
            tapable(c, () -> selectFilter(n));
            chipImgs[i] = iv; chipFrames[i] = ring; chipLabels[i] = lb;
            chips.addView(c);
        }
        filterStrip.addView(chips);
        camCol.addView(filterStrip, new LinearLayout.LayoutParams(-1, -2));
        // bottom panel
        bottomPanel = col(); bottomPanel.setBackgroundColor(Color.BLACK); bottomPanel.setPadding(dp(14), dp(8), dp(14), dp(10));
        FrameLayout scell = new FrameLayout(this);
        View ring = new View(this); GradientDrawable rg = oval(Color.TRANSPARENT); rg.setStroke(dp(4), Color.parseColor("#9A9A9F")); ring.setBackground(rg);
        scell.addView(ring, new FrameLayout.LayoutParams(dp(84), dp(84), Gravity.CENTER));
        shutterInner = new View(this); scell.addView(shutterInner, new FrameLayout.LayoutParams(dp(68), dp(68), Gravity.CENTER));
        tapable(scell, this::onShutter);
        bottomPanel.addView(scell, new LinearLayout.LayoutParams(-1, dp(90)));
        LinearLayout br = row(); br.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout gl = new LinearLayout(this); gl.setGravity(Gravity.START);
        galleryThumb = new ImageView(this); galleryThumb.setScaleType(ImageView.ScaleType.CENTER_CROP); galleryThumb.setBackground(shape(Color.parseColor("#2C2C2E"), 12)); clipRound(galleryThumb, 12);
        tapable(galleryThumb, () -> { stopIfNeeded(); stopCamera(); cameraScreen = false; tab = 3; enterApp(); });
        gl.addView(galleryThumb, new LinearLayout.LayoutParams(dp(46), dp(46)));
        if (lastUri != null) loadLocalThumb(lastUri, galleryThumb, 150);
        br.addView(gl, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout modes = row(); modes.setBackground(shape(Color.parseColor("#2C2C2E"), 22));
        modeVideo = text("VIDEO", 13, Color.WHITE, true); modePhoto = text("PHOTO", 13, Color.WHITE, true);
        modeVideo.setPadding(dp(16), dp(9), dp(16), dp(9)); modePhoto.setPadding(dp(16), dp(9), dp(16), dp(9));
        tapable(modeVideo, () -> { if (!recordingNow) { photoMode = false; updateMode(); } });
        tapable(modePhoto, () -> { if (!recordingNow) { photoMode = true; updateMode(); } });
        modes.addView(modeVideo); modes.addView(modePhoto);
        br.addView(modes);
        LinearLayout fl = new LinearLayout(this); fl.setGravity(Gravity.END);
        TextView flip = text("⟲", 20, Color.WHITE, true); flip.setGravity(Gravity.CENTER); flip.setBackground(oval(Color.parseColor("#2C2C2E")));
        tapable(flip, this::flipCamera);
        fl.addView(flip, new LinearLayout.LayoutParams(dp(46), dp(46)));
        br.addView(fl, new LinearLayout.LayoutParams(0, -2, 1f));
        bottomPanel.addView(br, lp(-1, -2, 4));
        camCol.addView(bottomPanel);
        camRoot.setOnApplyWindowInsetsListener((v, ins) -> { camCol.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom()); return ins; });
        setContentView(camRoot); camRoot.requestApplyInsets();
        fadeIn(camRoot, 0);
        updateMode(); selectFilter(filterIndex); startCamera();
        main.removeCallbacks(heartTick); main.removeCallbacks(thumbTick);
        heartTick = () -> { if (!cameraScreen) return; spawnHeart(); main.postDelayed(heartTick, 650); };
        thumbTick = () -> { if (!cameraScreen) return; refreshThumbs(); main.postDelayed(thumbTick, 1500); };
        main.postDelayed(heartTick, 800); main.postDelayed(thumbTick, 900);
    }

    private TextView zoomPill(String label, final float ratio) {
        TextView t = text(label, 13, Color.WHITE, true); t.setGravity(Gravity.CENTER);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
        tapable(t, () -> setZoomRatio(ratio));
        return t;
    }
    private void setZoomRatio(float r) {
        if (camera == null) return;
        ZoomState zs = camera.getCameraInfo().getZoomState().getValue();
        float lo = zs == null ? 1f : zs.getMinZoomRatio(), hi = zs == null ? 5f : Math.min(zs.getMaxZoomRatio(), 8f);
        curZoom = Math.max(lo, Math.min(hi, r));
        camera.getCameraControl().setZoomRatio(curZoom);
        updateZoomUi();
    }
    private void updateZoomUi() {
        if (zoomOne == null) return;
        float[] presets = {0.5f, 1f, 2f};
        TextView[] pills = {zoomHalf, zoomOne, zoomTwo};
        String[] labels = {"0.5", "1×", "2×"};
        int near = 1; float best = 99f;
        for (int i = 0; i < 3; i++) { float d = Math.abs(curZoom - presets[i]); if (d < best) { best = d; near = i; } }
        for (int i = 0; i < 3; i++) {
            boolean sel = i == near;
            pills[i].setTextColor(sel ? YELLOW : Color.WHITE);
            pills[i].setBackground(sel ? oval(Color.argb(160, 0, 0, 0)) : null);
            pills[i].setText(sel && best > 0.08f ? String.format(Locale.US, "%.1f×", curZoom) : labels[i]);
        }
    }
    private void focusAt(float x, float y) {
        if (camera == null || previewView == null) return;
        try {
            MeteringPoint pt = previewView.getMeteringPointFactory().createPoint(x, y);
            camera.getCameraControl().startFocusAndMetering(new FocusMeteringAction.Builder(pt).build());
        } catch (Exception ignored) { }
        if (hideFocus != null) main.removeCallbacks(hideFocus);
        try { exposureBase = camera.getCameraInfo().getExposureState().getExposureCompensationIndex(); } catch (Exception ignored) { exposureBase = 0; }
        focusBox.setTranslationX(x - dp(38)); focusBox.setTranslationY(y - dp(38));
        focusBox.setVisibility(View.VISIBLE); focusBox.setScaleX(1.3f); focusBox.setScaleY(1.3f);
        focusBox.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(new DecelerateInterpolator()).start();
        sunLine.setTranslationX(x + dp(52)); sunLine.setTranslationY(y - dp(55)); sunLine.setVisibility(View.VISIBLE);
        sunMarker.setTranslationX(x + dp(44)); sunMarker.setTranslationY(y - dp(14)); sunMarker.setVisibility(View.VISIBLE);
        tick(previewFrame);
    }
    private void adjustExposure(float dy) {
        if (camera == null) return;
        try {
            ExposureState es = camera.getCameraInfo().getExposureState();
            if (!es.isExposureCompensationSupported()) return;
            Range<Integer> r = es.getExposureCompensationRange();
            int idx = Math.max(r.getLower(), Math.min(r.getUpper(), exposureBase + Math.round(dy / dp(14))));
            camera.getCameraControl().setExposureCompensationIndex(idx);
            float frac = (idx - r.getLower()) / (float) Math.max(1, r.getUpper() - r.getLower());
            sunMarker.setTranslationY(sunLine.getTranslationY() + (1f - frac) * dp(110) - dp(12));
        } catch (Exception ignored) { }
    }
    private void scheduleHideFocus() {
        if (hideFocus != null) main.removeCallbacks(hideFocus);
        hideFocus = () -> { if (focusBox != null) { focusBox.setVisibility(View.GONE); sunLine.setVisibility(View.GONE); sunMarker.setVisibility(View.GONE); } };
        main.postDelayed(hideFocus, 2800);
    }
    private void selectFilter(int i) {
        filterIndex = i;
        if (chipFrames != null) for (int k = 0; k < chipFrames.length; k++) {
            GradientDrawable g = new GradientDrawable(); g.setCornerRadius(dp(15)); g.setColor(Color.TRANSPARENT);
            if (k == i) g.setStroke(dp(2), YELLOW);
            chipFrames[k].setBackground(g);
            chipLabels[k].setTextColor(k == i ? YELLOW : Color.WHITE);
        }
        applyFilterPreview();
    }
    private void applyFilterPreview() {
        if (previewView == null) return;
        if (filterIndex == 0) previewView.setLayerType(View.LAYER_TYPE_NONE, null);
        else { Paint p = new Paint(); p.setColorFilter(new ColorMatrixColorFilter(filterMatrix(filterIndex, intensity / 100f))); previewView.setLayerType(View.LAYER_TYPE_HARDWARE, p); }
    }
    private void refreshThumbs() {
        if (previewView == null || chipImgs == null) return;
        try {
            Bitmap full = previewView.getBitmap(); if (full == null) return;
            Bitmap small = Bitmap.createScaledBitmap(full, 84, 112, true);
            if (small != full) full.recycle();
            for (int i = 0; i < chipImgs.length; i++) {
                Bitmap o = Bitmap.createBitmap(84, 112, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(o); Paint p = new Paint(); p.setColorFilter(new ColorMatrixColorFilter(filterMatrix(i, 0.9f)));
                c.drawBitmap(small, 0, 0, p); chipImgs[i].setImageBitmap(o);
            }
            small.recycle();
        } catch (Exception ignored) { }
    }
    private void spawnHeart() {
        if (!cameraScreen || !effectsOn || previewFrame == null || previewFrame.getWidth() == 0) return;
        String set = heartSets[filterIndex];
        String[] opts = set.isEmpty() ? new String[]{"✨", "💗"} : set.split(",");
        final TextView t = text(opts[rnd.nextInt(opts.length)], 14 + rnd.nextInt(18), Color.WHITE, false);
        previewFrame.addView(t, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START));
        float startY = previewFrame.getHeight() - dp(80);
        t.setTranslationX(rnd.nextInt(Math.max(1, previewFrame.getWidth() - dp(40)))); t.setTranslationY(startY); t.setAlpha(0f);
        t.animate().translationY(startY - previewFrame.getHeight() * (0.45f + rnd.nextFloat() * 0.35f)).translationXBy((rnd.nextFloat() - .5f) * dp(60)).alpha(.95f)
                .setDuration(2600).setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> t.animate().alpha(0f).setDuration(500).withEndAction(() -> previewFrame.removeView(t)).start()).start();
    }
    private void updateMode() {
        if (modePhoto == null) return;
        modeVideo.setTextColor(photoMode ? Color.WHITE : YELLOW);
        modePhoto.setTextColor(photoMode ? YELLOW : Color.WHITE);
        updateShutter();
    }
    private void updateShutter() {
        if (shutterInner == null) return;
        int size = recordingNow ? 34 : 68;
        shutterInner.setBackground(recordingNow ? shape(Color.parseColor("#FF3B30"), 8) : oval(photoMode ? Color.WHITE : Color.parseColor("#FF3B30")));
        shutterInner.setLayoutParams(new FrameLayout.LayoutParams(dp(size), dp(size), Gravity.CENTER));
    }
    private void onShutter() {
        if (counting) return;
        final Runnable act;
        if (photoMode) act = this::takePhoto;
        else if (recordingNow) act = this::stopRecording;
        else act = this::startRecording;
        if (timerSec > 0 && !recordingNow) { counting = true; countdown(timerSec, () -> { counting = false; act.run(); }); }
        else act.run();
    }
    private void countdown(final int s, final Runnable done) {
        if (!cameraScreen) { counting = false; return; }
        if (s <= 0) { countdownText.setVisibility(View.GONE); done.run(); return; }
        countdownText.setText(String.valueOf(s)); countdownText.setVisibility(View.VISIBLE);
        countdownText.setScaleX(1.6f); countdownText.setScaleY(1.6f); countdownText.setAlpha(1f);
        countdownText.animate().scaleX(1f).scaleY(1f).alpha(.55f).setDuration(900).start();
        tick(countdownText);
        main.postDelayed(() -> countdown(s - 1, done), 1000);
    }
    private void strengthDialog() {
        SeekBar sb = new SeekBar(this); sb.setMax(100); sb.setProgress(intensity); sb.setPadding(dp(28), dp(24), dp(28), dp(8));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int value, boolean user) { intensity = value; applyFilterPreview(); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        new AlertDialog.Builder(this).setTitle("Filter strength").setView(sb).setPositiveButton("Done", null).show();
    }
    private void startCamera() {
        if (!cameraScreen || previewView == null) return;
        final ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                Recorder recorder = new Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.FHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.FHD))).build();
                videoCapture = VideoCapture.withOutput(recorder);
                imageCapture = new ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build();
                provider.unbindAll();
                camera = provider.bindToLifecycle(this, selector, preview, imageCapture, videoCapture);
                curZoom = 1f;
                ZoomState zs = camera.getCameraInfo().getZoomState().getValue();
                if (zoomHalf != null) zoomHalf.setVisibility(zs != null && zs.getMinZoomRatio() < 0.9f ? View.VISIBLE : View.GONE);
                updateZoomUi();
            } catch (ExecutionException | InterruptedException e) {
                toast("Camera failed to start.");
            } catch (Exception e) {
                toast("Camera error: " + e.getMessage());
            }
        }, ContextCompat.getMainExecutor(this));
    }
    private void stopCamera() {
        try {
            final ListenableFuture<ProcessCameraProvider> f = ProcessCameraProvider.getInstance(this);
            f.addListener(() -> { try { f.get().unbindAll(); } catch (Exception ignored) { } }, ContextCompat.getMainExecutor(this));
        } catch (Exception ignored) { }
    }
    private void closeCamera() { cameraScreen = false; stopIfNeeded(); stopCamera(); enterApp(); }
    private void flipCamera() {
        selector = selector == CameraSelector.DEFAULT_FRONT_CAMERA ? CameraSelector.DEFAULT_BACK_CAMERA : CameraSelector.DEFAULT_FRONT_CAMERA;
        flashOn = false; if (flashBtn != null) flashBtn.setTextColor(Color.WHITE);
        startCamera();
    }
    private void takePhoto() {
        if (imageCapture == null) { toast("Camera is still starting."); return; }
        if (soundOn && mas != null) mas.play(MediaActionSound.SHUTTER_CLICK);
        flashOverlay.setAlpha(0.85f); flashOverlay.animate().alpha(0f).setDuration(260).start();
        String name = "UsTwo_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".jpg";
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
        cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/UsTwo");
        ImageCapture.OutputFileOptions options = new ImageCapture.OutputFileOptions.Builder(getContentResolver(), MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv).build();
        final int idx = filterIndex, strength = intensity;
        imageCapture.takePicture(options, ContextCompat.getMainExecutor(this), new ImageCapture.OnImageSavedCallback() {
            @Override public void onImageSaved(ImageCapture.OutputFileResults result) {
                final Uri saved = result.getSavedUri();
                if (saved == null) { toast("Photo saved."); return; }
                lastUri = saved;
                io.execute(() -> {
                    applyFilterToSavedImage(saved, idx, strength);
                    runOnUiThread(() -> { if (galleryThumb != null && cameraScreen) loadLocalThumb(saved, galleryThumb, 150); });
                });
            }
            @Override public void onError(ImageCaptureException e) { toast("Photo failed: " + e.getMessage()); }
        });
    }
    private void applyFilterToSavedImage(Uri uri, int idx, int strength) {
        if (idx == 0) return;
        try {
            int rot = 0;
            try (InputStream ei = getContentResolver().openInputStream(uri)) {
                ExifInterface ex = new ExifInterface(ei);
                int o = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                rot = o == ExifInterface.ORIENTATION_ROTATE_90 ? 90 : o == ExifInterface.ORIENTATION_ROTATE_180 ? 180 : o == ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
            }
            BitmapFactory.Options bounds = new BitmapFactory.Options(); bounds.inJustDecodeBounds = true;
            try (InputStream bi = getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(bi, null, bounds); }
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = (long) bounds.outWidth * bounds.outHeight > 16000000L ? 2 : 1;
            Bitmap src;
            try (InputStream si = getContentResolver().openInputStream(uri)) { src = BitmapFactory.decodeStream(si, null, opts); }
            if (src == null) return;
            Bitmap base = src;
            if (rot != 0) { Matrix mx = new Matrix(); mx.postRotate(rot); base = Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), mx, true); }
            Bitmap out = Bitmap.createBitmap(base.getWidth(), base.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(out);
            Paint p = new Paint(); p.setColorFilter(new ColorMatrixColorFilter(filterMatrix(idx, strength / 100f)));
            cv.drawBitmap(base, 0, 0, p);
            try (OutputStream os = getContentResolver().openOutputStream(uri, "wt")) { out.compress(Bitmap.CompressFormat.JPEG, 92, os); }
        } catch (Exception ignored) { }
    }
    private void startRecording() {
        if (videoCapture == null || recordingNow) return;
        String name = "UsTwo_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
        cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/UsTwo");
        MediaStoreOutputOptions output = new MediaStoreOutputOptions.Builder(getContentResolver(), MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(cv).build();
        PendingRecording pending = videoCapture.getOutput().prepareRecording(this, output);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) pending = pending.withAudioEnabled();
        if (soundOn && mas != null) mas.play(MediaActionSound.START_VIDEO_RECORDING);
        recording = pending.start(ContextCompat.getMainExecutor(this), event -> {
            if (event instanceof VideoRecordEvent.Start) {
                recordingNow = true; updateShutter();
                if (recTimer != null) { recTimer.setText("● 00:00"); recTimer.setVisibility(View.VISIBLE); }
            } else if (event instanceof VideoRecordEvent.Status) {
                long ns = ((VideoRecordEvent.Status) event).getRecordingStats().getRecordedDurationNanos();
                if (recTimer != null) recTimer.setText("● " + fmt(ns / 1000000L));
            } else if (event instanceof VideoRecordEvent.Finalize) {
                recordingNow = false; recording = null;
                VideoRecordEvent.Finalize fin = (VideoRecordEvent.Finalize) event;
                if (recTimer != null) recTimer.setVisibility(View.GONE);
                updateShutter();
                if (!fin.hasError()) {
                    lastUri = fin.getOutputResults().getOutputUri();
                    if (cameraScreen) { stopCamera(); showPlayer(lastUri, true, this::enterApp); }
                    else toast("Video saved in Movies/UsTwo.");
                } else toast("Recording failed. Try again.");
            }
        });
    }
    private void stopRecording() {
        if (soundOn && mas != null) mas.play(MediaActionSound.STOP_VIDEO_RECORDING);
        if (recording != null) recording.stop();
    }
    private void stopIfNeeded() { if (recording != null) recording.stop(); }
}
