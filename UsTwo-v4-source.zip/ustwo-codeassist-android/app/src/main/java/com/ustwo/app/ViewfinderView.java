package com.ustwo.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

/** Retro digital-camera viewfinder overlay: brackets, vignette, scanlines, film grain, REC light, orange date stamp. */
public class ViewfinderView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vigPaint = new Paint();
    private final Paint scanPaint = new Paint();
    private final Paint grainPaint = new Paint();
    private final Bitmap grain = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888);
    private final int[] gpx = new int[96 * 96];
    private final Random rnd = new Random();
    private final float d;
    private boolean rec = false, dateStamp = true, blink = true, attached = false;
    private String recTime = "00:00";
    private int ticks = 0;
    private float insetTop, insetBottom;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!attached) return;
            regrain();
            if (++ticks % 5 == 0) blink = !blink;
            invalidate();
            postDelayed(this, 110);
        }
    };

    public ViewfinderView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        insetTop = 96 * d; insetBottom = 270 * d;
        setClickable(false); setFocusable(false);
        Bitmap tile = Bitmap.createBitmap(1, 4, Bitmap.Config.ARGB_8888);
        tile.setPixel(0, 0, 0x22000000);
        scanPaint.setShader(new BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
        regrain();
    }

    public void setRecording(boolean r, String t) { rec = r; recTime = t; invalidate(); }
    public void setDateStamp(boolean on) { dateStamp = on; invalidate(); }
    public void setInsets(float top, float bottom) { insetTop = top; insetBottom = bottom; invalidate(); }

    private void regrain() {
        for (int i = 0; i < gpx.length; i++) {
            int v = rnd.nextInt(256), a = 10 + rnd.nextInt(22);
            gpx[i] = (a << 24) | (v << 16) | (v << 8) | v;
        }
        grain.setPixels(gpx, 0, 96, 0, 0, 96, 96);
        BitmapShader s = new BitmapShader(grain, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
        Matrix m = new Matrix(); m.setScale(3f, 3f); s.setLocalMatrix(m);
        grainPaint.setShader(s);
    }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); attached = true; post(tick); }
    @Override protected void onDetachedFromWindow() { attached = false; removeCallbacks(tick); super.onDetachedFromWindow(); }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        vigPaint.setShader(new RadialGradient(w / 2f, h / 2f, Math.max(w, h) * 0.78f,
                new int[]{0x00000000, 0x00000000, 0xAA000000}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawRect(0, 0, w, h, vigPaint);
        c.drawRect(0, 0, w, h, scanPaint);
        c.drawRect(0, 0, w, h, grainPaint);

        float m = 20 * d, L = 28 * d;
        float l = m, r = w - m, t = insetTop, b = h - insetBottom;
        paint.setShadowLayer(0, 0, 0, 0);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2.6f * d); paint.setColor(0xE6FFFFFF);
        c.drawLine(l, t, l + L, t, paint); c.drawLine(l, t, l, t + L, paint);
        c.drawLine(r, t, r - L, t, paint); c.drawLine(r, t, r, t + L, paint);
        c.drawLine(l, b, l + L, b, paint); c.drawLine(l, b, l, b - L, paint);
        c.drawLine(r, b, r - L, b, paint); c.drawLine(r, b, r, b - L, paint);

        float cx = w / 2f, cy = (t + b) / 2f, f = 22 * d;
        paint.setStrokeWidth(1.6f * d); paint.setColor(0xB3FFFFFF);
        c.drawLine(cx - f, cy - f, cx - f + 9 * d, cy - f, paint); c.drawLine(cx - f, cy - f, cx - f, cy - f + 9 * d, paint);
        c.drawLine(cx + f, cy - f, cx + f - 9 * d, cy - f, paint); c.drawLine(cx + f, cy - f, cx + f, cy - f + 9 * d, paint);
        c.drawLine(cx - f, cy + f, cx - f + 9 * d, cy + f, paint); c.drawLine(cx - f, cy + f, cx - f, cy + f - 9 * d, paint);
        c.drawLine(cx + f, cy + f, cx + f - 9 * d, cy + f, paint); c.drawLine(cx + f, cy + f, cx + f, cy + f - 9 * d, paint);
        c.drawCircle(cx, cy, 1.8f * d, paint);

        paint.setStyle(Paint.Style.FILL); paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        paint.setTextSize(12 * d); paint.setTextAlign(Paint.Align.LEFT);
        float tx = l + 10 * d, ty = t + 24 * d;
        if (rec) {
            paint.setColor(blink ? 0xFFFF3B4E : 0x55FF3B4E);
            c.drawCircle(tx + 5 * d, ty - 4 * d, 5 * d, paint);
            paint.setColor(Color.WHITE); c.drawText("REC " + recTime, tx + 16 * d, ty, paint);
        } else {
            paint.setColor(0xFFFFFFFF); c.drawText("STBY", tx, ty, paint);
        }
        paint.setColor(0xCCFFFFFF); paint.setTextAlign(Paint.Align.RIGHT);
        c.drawText("1080P", r - 38 * d, ty, paint);
        float bx = r - 30 * d, by = ty - 11 * d;
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.5f * d); paint.setColor(0xCCFFFFFF);
        c.drawRect(bx, by, bx + 22 * d, by + 11 * d, paint);
        paint.setStyle(Paint.Style.FILL);
        c.drawRect(bx + 22 * d, by + 3.5f * d, bx + 24.5f * d, by + 7.5f * d, paint);
        for (int i = 0; i < 3; i++) c.drawRect(bx + (2 + i * 6.2f) * d, by + 2 * d, bx + (6.6f + i * 6.2f) * d, by + 9 * d, paint);

        paint.setTextAlign(Paint.Align.LEFT); paint.setTextSize(11 * d); paint.setColor(0xCCFFFFFF);
        c.drawText("AF  1/60  F2.8", l + 10 * d, b - 14 * d, paint);

        if (dateStamp) {
            String s = new SimpleDateFormat("''yy MM dd", Locale.US).format(new Date());
            paint.setTextAlign(Paint.Align.RIGHT); paint.setTextSize(19 * d); paint.setColor(0xFFFF8C1A);
            paint.setShadowLayer(7 * d, 0, 0, 0xAAFF6A00);
            c.drawText(s, r - 10 * d, b - 14 * d, paint);
            paint.setShadowLayer(0, 0, 0, 0);
        }
    }
}
