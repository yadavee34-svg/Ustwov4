package com.ustwo.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Floating hearts (ambient) and one-shot heart bursts (celebrations). Never blocks touches. */
public class HeartsView extends View {
    private static class P { float x, y, vx, vy, g, size, alpha, life, maxLife, rot, vr; int color; String glyph; }

    private final List<P> ps = new ArrayList<>();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rnd = new Random();
    private final boolean ambient;
    private final float baseAlpha;
    private final int count;
    private final float d;
    private long last = 0;
    private final int[] colors = {0xFFFF8FA3, 0xFFFDD6E7, 0xFFFFE3E7, 0xFFFFFFFF, 0xFFFFB3C1};
    private final String[] glyphs = {"♥", "♥", "♥", "✦"};

    public HeartsView(Context c, boolean ambient, float alpha, int count) {
        super(c);
        this.ambient = ambient; this.baseAlpha = alpha; this.count = count;
        this.d = c.getResources().getDisplayMetrics().density;
        setClickable(false); setFocusable(false);
        paint.setTextAlign(Paint.Align.CENTER);
    }

    private void respawn(P p, int w, int h, boolean anywhere) {
        p.x = rnd.nextFloat() * w;
        p.y = anywhere ? rnd.nextFloat() * h : h + 30 * d;
        p.vx = 0; p.vy = -(26 + rnd.nextFloat() * 44) * d; p.g = 0;
        p.size = (12 + rnd.nextFloat() * 22) * d;
        p.alpha = baseAlpha * (0.45f + rnd.nextFloat() * 0.55f);
        p.life = anywhere ? rnd.nextFloat() * 6f : 0f;
        p.maxLife = 9f + rnd.nextFloat() * 6f;
        p.rot = rnd.nextFloat() * 40f - 20f; p.vr = 0;
        p.color = colors[rnd.nextInt(colors.length)];
        p.glyph = glyphs[rnd.nextInt(glyphs.length)];
    }

    public void burst(float cx, float cy) {
        for (int i = 0; i < 30; i++) {
            P p = new P();
            double a = rnd.nextDouble() * Math.PI * 2;
            float sp = (220 + rnd.nextFloat() * 520) * d;
            p.x = cx; p.y = cy; p.vx = (float) Math.cos(a) * sp; p.vy = (float) Math.sin(a) * sp - 260 * d;
            p.g = 620 * d; p.size = (14 + rnd.nextFloat() * 22) * d; p.alpha = 1f;
            p.life = 0; p.maxLife = 1.1f + rnd.nextFloat() * 0.9f;
            p.rot = rnd.nextFloat() * 60f - 30f; p.vr = rnd.nextFloat() * 160f - 80f;
            p.color = colors[rnd.nextInt(colors.length - 1)];
            p.glyph = glyphs[rnd.nextInt(glyphs.length)];
            ps.add(p);
        }
        last = 0; invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        if (ambient) {
            while (ps.size() < count) { P p = new P(); respawn(p, w, h, true); ps.add(p); }
        }
        for (int i = ps.size() - 1; i >= 0; i--) {
            P p = ps.get(i);
            p.life += dt;
            p.vy += p.g * dt;
            p.x += p.vx * dt + (ambient ? (float) Math.sin(p.life * 1.4f + p.rot) * 14f * d * dt : 0f);
            p.y += p.vy * dt;
            p.rot += p.vr * dt;
            float t = p.life / p.maxLife;
            if (t >= 1f || p.y < -60 * d) {
                if (ambient) respawn(p, w, h, false); else ps.remove(i);
                continue;
            }
            float a = p.alpha * (t < 0.15f ? t / 0.15f : t > 0.7f ? (1f - t) / 0.3f : 1f);
            paint.setColor(p.color);
            paint.setAlpha(Math.max(0, Math.min(255, (int) (255 * a))));
            paint.setTextSize(p.size);
            c.save(); c.rotate(p.rot, p.x, p.y); c.drawText(p.glyph, p.x, p.y, paint); c.restore();
        }
        if (ambient || !ps.isEmpty()) postInvalidateOnAnimation();
    }
}
