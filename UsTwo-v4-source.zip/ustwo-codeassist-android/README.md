# UsTwo v4.0 (native Android, Java)

New in v4: three themes (Blush Pink, Midnight, Cream & Rose), iOS-style camera (grid, tap-to-focus,
exposure slider, 0.5/1x/2x zoom, timer, real live filter previews), chat (text, photos, voice notes,
hearts), Home with days-together card, Timeline, Special Dates, Shared Notes, articles, sounds and haptics.

## Firebase setup (project ustwo-6d35b)
1. Authentication > Sign-in method > Email/Password > Enable.
2. Firestore Database (Standard, production mode). Paste `firestore.rules` in Rules and Publish.
   NOTE: v4 rules add `couples/...` for chat and shared lists. You must re-publish them.
3. Storage: paste `storage.rules` in Rules and Publish.

## Partner linking
Profile shows your pairing code. Each of you enters the other's code. Chat, timeline, dates and notes
are shared through a private pair space that only the two of you can read.

## Notes
- Filters are live on the preview and saved into photos. Video filters are preview-only.
- Chat updates live while the app is open. Background push notifications are not included.
- Articles are short original reads bundled in the app.
